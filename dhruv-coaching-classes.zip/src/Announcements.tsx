import React, { useState, useEffect } from 'react';
import { collection, getDocs, addDoc, deleteDoc, doc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { useAuth } from './AuthContext';
import { Trash2, Plus, X, BellRing } from 'lucide-react';

interface Announcement {
  id?: string;
  title: string;
  batchName?: string;
  description?: string;
  posted: string;
}

const DEFAULT_ANNOUNCEMENTS = [
  { title: 'Holiday Notice', batchName: 'All Batches', description: 'Classes will remain suspended on account of the upcoming national festival.', posted: '15/07/2026, 10:17:37' },
  { title: 'Term 1 Schedule Released', batchName: 'JEE Advanced 2026', description: 'Please download the syllabus sheet and term dates from the study material tab.', posted: '15/07/2026, 10:17:37' }
];

export default function Announcements() {
  const { role } = useAuth();
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [batches, setBatches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);

  // Form states
  const [newTitle, setNewTitle] = useState('');
  const [newBatch, setNewBatch] = useState('All Batches');
  const [newDescription, setNewDescription] = useState('');

  const isStaff = role === 'admin' || role === 'teacher';

  const fetchAnnouncements = async () => {
    try {
      setLoading(true);
      const snap = await getDocs(collection(db, 'announcements'));
      let fetched = snap.docs.map(d => ({ id: d.id, ...d.data() } as Announcement));

      const bSnap = await getDocs(collection(db, 'batches'));
      const fetchedBatches = bSnap.docs.map(d => ({ id: d.id, ...d.data() }));
      setBatches(fetchedBatches);

      if (fetched.length === 0) {
        // Auto-seed with default announcements matching screenshots exactly
        for (const item of DEFAULT_ANNOUNCEMENTS) {
          const docRef = await addDoc(collection(db, 'announcements'), item);
          fetched.push({ id: docRef.id, ...item });
        }
      }
      
      setAnnouncements(fetched);
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'announcements');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnnouncements();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDescription.trim()) return;

    // Format current date exactly like screenshots: 15/07/2026, 10:47:07
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    const formattedDate = `${pad(now.getDate())}/${pad(now.getMonth() + 1)}/${now.getFullYear()}, ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;

    const newAnn = {
      title: newTitle.trim(),
      batchName: newBatch,
      description: newDescription.trim(),
      posted: formattedDate
    };

    try {
      await addDoc(collection(db, 'announcements'), newAnn);
      setNewTitle('');
      setNewDescription('');
      setNewBatch('All Batches');
      setShowAddForm(false);
      fetchAnnouncements();
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'announcements');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this announcement?')) return;
    try {
      await deleteDoc(doc(db, 'announcements', id));
      fetchAnnouncements();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'announcements');
    }
  };

  if (loading) {
    return (
      <div className="min-h-[400px] flex flex-col items-center justify-center font-sans">
        <div className="w-10 h-10 border-4 border-[#0070f3] border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-slate-500 font-semibold text-sm">Loading announcements...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12 font-sans select-none">
      {/* Page Header */}
      <div className="flex justify-between items-center">
        <div>
          <span className="text-xs font-black text-slate-400 uppercase tracking-widest block mb-0.5">ADMIN</span>
          <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight">Announcements</h1>
          <p className="text-slate-500 text-sm mt-1 font-semibold">Post official announcements</p>
        </div>
        {isStaff && (
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center gap-2 px-6 py-3 bg-[#0070f3] hover:bg-[#0060df] text-white rounded-full font-bold text-sm shadow-md shadow-blue-500/10 active:scale-[0.98] transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Announcement</span>
          </button>
        )}
      </div>

      {/* Table Section */}
      <div className="bg-white rounded-[32px] border border-slate-200/50 shadow-sm overflow-hidden flex flex-col animate-fadeIn">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100">
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs w-[40%]">Title</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Target Batch</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Posted At</th>
                {isStaff && <th className="px-8 py-5 w-[10%]"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {announcements.map((ann) => (
                <tr key={ann.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-8 py-5">
                    <div className="text-slate-800 font-semibold text-sm flex items-center gap-2">
                      <span className="p-1.5 bg-blue-50 text-[#0070f3] rounded-lg">
                        <BellRing className="w-3.5 h-3.5" />
                      </span>
                      {ann.title}
                    </div>
                    {ann.description && (
                      <div className="text-slate-400 text-xs mt-1.5 font-medium max-w-md line-clamp-1">
                        {ann.description}
                      </div>
                    )}
                  </td>
                  <td className="px-8 py-5 text-slate-500 font-semibold text-sm">
                    <span className="bg-slate-100 px-3 py-1 rounded-full text-xs text-slate-700 font-bold">
                      {ann.batchName || 'All Batches'}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-slate-500 font-medium text-sm">
                    {ann.posted}
                  </td>
                  {isStaff && (
                    <td className="px-8 py-5 text-right">
                      <button
                        onClick={() => handleDelete(ann.id!)}
                        className="text-slate-400 hover:text-red-500 p-2 rounded-lg hover:bg-red-50/50 transition-all cursor-pointer"
                        title="Delete Announcement"
                      >
                        <Trash2 className="w-5 h-5" strokeWidth={1.5} />
                      </button>
                    </td>
                  )}
                </tr>
              ))}
              {announcements.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-8 py-12 text-center text-slate-400 font-medium text-sm">
                    No announcements posted.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Announcement Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-3xl shadow-xl w-full max-w-md overflow-hidden border border-slate-100 p-6 space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-950 text-lg flex items-center gap-2">
                <BellRing className="w-5 h-5 text-[#0070f3]" />
                Add Announcement
              </h3>
              <button onClick={() => setShowAddForm(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Announcement Title</label>
                <input
                  required
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium placeholder-slate-400 text-sm"
                  placeholder="e.g. New Session Timetable"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Batch</label>
                <select
                  value={newBatch}
                  onChange={(e) => setNewBatch(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm bg-white"
                >
                  <option value="All Batches">All Batches</option>
                  {batches.map((b) => (
                    <option key={b.id} value={b.name || b.class}>
                      {b.name || b.class}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Description</label>
                <textarea
                  required
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  rows={4}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium placeholder-slate-400 text-sm resize-none"
                  placeholder="Enter detailed notice information..."
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-5 py-2.5 text-slate-500 font-bold text-sm hover:bg-slate-50 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#0070f3] hover:bg-[#0060df] text-white font-bold text-sm rounded-xl shadow-md cursor-pointer"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
