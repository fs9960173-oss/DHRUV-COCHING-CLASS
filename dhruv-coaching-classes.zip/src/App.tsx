import React from 'react';
import { Routes, Route, Navigate } from 'react-router';
import { useAuth } from './AuthContext';
import Login from './Login';
import Layout from './Layout';
import Dashboard from './Dashboard';
import Students from './Students';
import Teachers from './Teachers';
import Attendance from './Attendance';
import Marks from './Marks';
import Fees from './Fees';
import Enrollments from './Enrollments';
import Lectures from './Lectures';
import LiveClasses from './LiveClasses';
import Announcements from './Announcements';
import Batches from './Batches';
import Courses from './Courses';
import StudyMaterial from './StudyMaterial';
import Tests from './Tests';
import Homework from './Homework';
import Notifications from './Notifications';
import Timetable from './Timetable';
import Performance from './Performance';
import Profile from './Profile';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="flex items-center justify-center min-h-screen bg-slate-50">Loading Portal...</div>;
  if (!user) return <Navigate to="/" />;
  return <>{children}</>;
}

export default function App() {
  const { isEnrolled, loading } = useAuth();

  if (loading) return <div className="flex items-center justify-center min-h-screen bg-slate-50">Loading Portal...</div>;

  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
        <Route path="dashboard" element={<Dashboard />} />
        
        {/* Only allow access to these pages if they are enrolled (approved student or staff) */}
        <Route path="lectures" element={isEnrolled ? <Lectures /> : <Navigate to="/dashboard" />} />
        <Route path="live-classes" element={isEnrolled ? <LiveClasses /> : <Navigate to="/dashboard" />} />
        <Route path="announcements" element={isEnrolled ? <Announcements /> : <Navigate to="/dashboard" />} />
        <Route path="batches" element={isEnrolled ? <Batches /> : <Navigate to="/dashboard" />} />
        <Route path="courses" element={isEnrolled ? <Courses /> : <Navigate to="/dashboard" />} />
        <Route path="study-material" element={isEnrolled ? <StudyMaterial /> : <Navigate to="/dashboard" />} />
        <Route path="tests" element={isEnrolled ? <Tests /> : <Navigate to="/dashboard" />} />
        <Route path="homework" element={isEnrolled ? <Homework /> : <Navigate to="/dashboard" />} />
        <Route path="timetable" element={isEnrolled ? <Timetable /> : <Navigate to="/dashboard" />} />
        <Route path="notifications" element={isEnrolled ? <Notifications /> : <Navigate to="/dashboard" />} />
        <Route path="performance" element={isEnrolled ? <Performance /> : <Navigate to="/dashboard" />} />
        <Route path="profile" element={isEnrolled ? <Profile /> : <Navigate to="/dashboard" />} />
        <Route path="students" element={isEnrolled ? <Students /> : <Navigate to="/dashboard" />} />
        <Route path="teachers" element={isEnrolled ? <Teachers /> : <Navigate to="/dashboard" />} />
        <Route path="attendance" element={isEnrolled ? <Attendance /> : <Navigate to="/dashboard" />} />
        <Route path="marks" element={isEnrolled ? <Marks /> : <Navigate to="/dashboard" />} />
        <Route path="fees" element={isEnrolled ? <Fees /> : <Navigate to="/dashboard" />} />
        <Route path="enrollments" element={isEnrolled ? <Enrollments /> : <Navigate to="/dashboard" />} />

        {/* Support admin prefix URLs from screenshots exactly */}
        <Route path="admin/courses" element={isEnrolled ? <Courses /> : <Navigate to="/dashboard" />} />
        <Route path="admin/live-classes" element={isEnrolled ? <LiveClasses /> : <Navigate to="/dashboard" />} />
        <Route path="admin/lectures" element={isEnrolled ? <Lectures /> : <Navigate to="/dashboard" />} />
        <Route path="admin/materials" element={isEnrolled ? <StudyMaterial /> : <Navigate to="/dashboard" />} />
        <Route path="admin/homework" element={isEnrolled ? <Homework /> : <Navigate to="/dashboard" />} />
        <Route path="admin/tests" element={isEnrolled ? <Tests /> : <Navigate to="/dashboard" />} />
        <Route path="admin/notifications" element={isEnrolled ? <Notifications /> : <Navigate to="/dashboard" />} />
        <Route path="admin/announcements" element={isEnrolled ? <Announcements /> : <Navigate to="/dashboard" />} />
      </Route>
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
}
