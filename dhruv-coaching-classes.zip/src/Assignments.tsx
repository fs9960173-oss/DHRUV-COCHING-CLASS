import React, { useEffect, useState } from 'react';
import { collection, getDocs, addDoc, query, where } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { Assignment, Student } from './types';
import { useAuth } from './AuthContext';
import { Plus, X, Calendar } from 'lucide-react';

export default function Assignments() {
  const { role, user } = useAuth();
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);

  useEffect(() => {
    async function fetchData() {
      setLoading(true);
      try {
        if (role === 'student') {
          const sq = query(collection(db, 'students'), where('userId', '==', user?.uid || ''));
          const studentSnap = await getDocs(sq);
          if (!studentSnap.empty) {
            const student = studentSnap.docs[0].data() as Student;
            const aq = query(collection(db, 'assignments'), where('class', '==', student.class), where('course', '==', student.course));
            const asnSnap = await getDocs(aq);
            setAssignments(asnSnap.docs.map(d => ({ id: d.id, ... (d.data() as any) } as Assignment)));
          }
        } else {
          const asnSnap = await getDocs(collection(db, 'assignments'));
          setAssignments(asnSnap.docs.map(d => ({ id: d.id, ... (d.data() as any) } as Assignment)));
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'assignments');
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, [role, user]);

  const handleAdd = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const newAsn = {
      title: fd.get('title') as string,
      description: fd.get('description') as string,
      class: fd.get('class') as string,
      course: fd.get('course') as string,
      dueDate: fd.get('dueDate') as string,
    };

    try {
      const docRef = await addDoc(collection(db, 'assignments'), newAsn);
      setShowAddModal(false);
      setAssignments(prev => [...prev, { id: docRef.id, ...newAsn }]);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'assignments');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <h1 className="text-2xl font-bold text-slate-900">Assignments</h1>
        {(role === 'admin' || role === 'teacher') && (
          <button 
            onClick={() => setShowAddModal(true)}
            className="flex items-center justify-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Create Assignment
          </button>
        )}
      </div>

      {loading ? (
        <div className="text-center py-12 text-slate-500">Loading assignments...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {assignments.length === 0 ? (
            <div className="col-span-full py-12 text-center text-slate-500 bg-white rounded-xl border border-dashed border-slate-300">
              No assignments found.
            </div>
          ) : (
            assignments.map(a => (
              <div key={a.id} className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 flex flex-col hover:border-indigo-300 transition-colors">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-bold text-slate-900 text-lg">{a.title}</h3>
                  <span className="inline-flex px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-100 text-indigo-800 uppercase shrink-0 ml-2">
                    {a.class}
                  </span>
                </div>
                <p className="text-indigo-600 font-medium text-sm mb-4">{a.course}</p>
                <p className="text-slate-600 text-sm flex-1 whitespace-pre-wrap mb-4 line-clamp-3">{a.description}</p>
                <div className="pt-4 border-t border-slate-100 flex items-center text-sm font-medium text-slate-500">
                  <Calendar className="w-4 h-4 mr-2" />
                  Due: {new Date(a.dueDate).toLocaleDateString()}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden flex flex-col max-h-[90vh]">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 shrink-0">
              <h3 className="font-bold text-lg text-slate-900">Create Assignment</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAdd} className="p-6 space-y-4 overflow-y-auto">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Title</label>
                <input required name="title" type="text" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="Chapter 1 Exercises" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Class</label>
                  <select required name="class" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none">
                    <option value="Class 10">Class 10</option>
                    <option value="Class 11">Class 11</option>
                    <option value="Class 12">Class 12</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Course</label>
                  <select required name="course" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none">
                    <option value="Mathematics">Mathematics</option>
                    <option value="Science">Science</option>
                    <option value="Crash Course">Crash Course</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Description</label>
                <textarea required name="description" rows={4} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none resize-none" placeholder="Complete exercises 1 to 10..." />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Due Date</label>
                <input required name="dueDate" type="date" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
              </div>
              <div className="pt-4 flex justify-end gap-3 shrink-0">
                <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 text-slate-600 font-medium hover:bg-slate-50 rounded-lg">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700">Create Assignment</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
