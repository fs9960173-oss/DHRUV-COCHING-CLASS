import React, { useEffect, useState } from 'react';
import { collection, getDocs, query, where, addDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { Student, Attendance as AttendanceType } from './types';
import { useAuth } from './AuthContext';
import { format } from 'date-fns';
import { CheckCircle2, XCircle, Clock } from 'lucide-react';

export default function Attendance() {
  const { role, user } = useAuth();
  const [students, setStudents] = useState<Student[]>([]);
  const [attendances, setAttendances] = useState<AttendanceType[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [filterClass, setFilterClass] = useState('Class 10');

  useEffect(() => {
    async function fetchData() {
      setLoading(true);
      try {
        if (role === 'student') {
          // Find student ID
          const sq = query(collection(db, 'students'), where('userId', '==', user?.uid || ''));
          const studentSnap = await getDocs(sq);
          if (!studentSnap.empty) {
            const studentId = studentSnap.docs[0].id;
            const aq = query(collection(db, 'attendance'), where('studentId', '==', studentId));
            const attSnap = await getDocs(aq);
            setAttendances(attSnap.docs.map(d => ({ id: d.id, ... (d.data() as any) } as AttendanceType)));
          }
        } else {
          // Staff view
          const sq = query(collection(db, 'students'), where('class', '==', filterClass));
          const studentSnap = await getDocs(sq);
          setStudents(studentSnap.docs.map(d => ({ id: d.id, ... (d.data() as any) } as Student)));

          const aq = query(collection(db, 'attendance'), where('date', '==', selectedDate));
          const attSnap = await getDocs(aq);
          setAttendances(attSnap.docs.map(d => ({ id: d.id, ... (d.data() as any) } as AttendanceType)));
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'attendance');
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, [role, user, selectedDate, filterClass]);

  const handleMarkAttendance = async (studentId: string, status: 'present' | 'absent' | 'late') => {
    try {
      const newAtt = { studentId, date: selectedDate, status };
      const docRef = await addDoc(collection(db, 'attendance'), newAtt);
      setAttendances(prev => {
        // Remove existing for this student on this date if any (in a real app, we'd update, but for simplicity we just add/replace locally)
        const filtered = prev.filter(a => a.studentId !== studentId);
        return [...filtered, { id: docRef.id, ...newAtt }];
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'attendance');
    }
  };

  if (role === 'student') {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-slate-900">My Attendance Record</h1>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-sm font-medium text-slate-500 uppercase">
                <th className="px-6 py-4">Date</th>
                <th className="px-6 py-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {attendances.length === 0 ? (
                <tr><td colSpan={2} className="px-6 py-8 text-center text-slate-500">No attendance records found.</td></tr>
              ) : (
                attendances.map(record => (
                  <tr key={record.id}>
                    <td className="px-6 py-4 text-slate-900 font-medium">{new Date(record.date).toLocaleDateString()}</td>
                    <td className="px-6 py-4">
                      {record.status === 'present' && <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-sm font-medium bg-green-50 text-green-700"><CheckCircle2 className="w-4 h-4"/> Present</span>}
                      {record.status === 'absent' && <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-sm font-medium bg-red-50 text-red-700"><XCircle className="w-4 h-4"/> Absent</span>}
                      {record.status === 'late' && <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-sm font-medium bg-orange-50 text-orange-700"><Clock className="w-4 h-4"/> Late</span>}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  // Admin/Teacher view
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-2xl font-bold text-slate-900">Mark Attendance</h1>
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <input 
            type="date" 
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none w-full sm:w-auto"
          />
          <select 
            value={filterClass}
            onChange={(e) => setFilterClass(e.target.value)}
            className="px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none w-full sm:w-auto"
          >
            <option value="Class 10">Class 10</option>
            <option value="Class 11">Class 11</option>
            <option value="Class 12">Class 12</option>
          </select>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-500">Loading...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 font-medium uppercase text-xs sticky top-0">
                <tr className="border-b border-slate-200">
                  <th className="px-4 py-3">Student Name</th>
                  <th className="px-4 py-3">Course</th>
                  <th className="px-4 py-3 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {students.length === 0 ? (
                  <tr><td colSpan={3} className="px-4 py-8 text-center text-slate-500">No students found in this class.</td></tr>
                ) : (
                  students.map(student => {
                    const record = attendances.find(a => a.studentId === student.id);
                    return (
                      <tr key={student.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-4 py-3 font-medium text-slate-900">{student.name}</td>
                        <td className="px-4 py-3 text-slate-600">{student.course}</td>
                        <td className="px-4 py-3 flex justify-end gap-2">
                        <button 
                          onClick={() => handleMarkAttendance(student.id!, 'present')}
                          className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${record?.status === 'present' ? 'bg-green-100 text-green-800 ring-2 ring-green-600 ring-offset-1' : 'bg-slate-100 text-slate-600 hover:bg-green-50 hover:text-green-700'}`}
                        >
                          Present
                        </button>
                        <button 
                          onClick={() => handleMarkAttendance(student.id!, 'absent')}
                          className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${record?.status === 'absent' ? 'bg-red-100 text-red-800 ring-2 ring-red-600 ring-offset-1' : 'bg-slate-100 text-slate-600 hover:bg-red-50 hover:text-red-700'}`}
                        >
                          Absent
                        </button>
                        <button 
                          onClick={() => handleMarkAttendance(student.id!, 'late')}
                          className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${record?.status === 'late' ? 'bg-orange-100 text-orange-800 ring-2 ring-orange-600 ring-offset-1' : 'bg-slate-100 text-slate-600 hover:bg-orange-50 hover:text-orange-700'}`}
                        >
                          Late
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
          </div>
        )}
      </div>
    </div>
  );
}
