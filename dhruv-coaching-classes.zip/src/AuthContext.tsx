import React, { createContext, useContext, useEffect, useState } from 'react';
import { auth, db, handleFirestoreError, OperationType } from './firebase';
import { onAuthStateChanged, User as FirebaseUser, signInAnonymously } from 'firebase/auth';
import { doc, getDoc, setDoc, collection, query, where, getDocs, limit, onSnapshot, addDoc } from 'firebase/firestore';
import { Role, User } from './types';

interface AuthContextType {
  user: any | null;
  role: Role | null;
  loading: boolean;
  isEnrolled: boolean;
  isApplied: boolean;
  enrollmentStatus: 'pending' | 'approved' | 'rejected' | null;
  studentBatchId: string | null;
  loginWithPhone: (phone: string) => Promise<void>;
  loginAsAdmin: (id: string, pass: string) => Promise<boolean>;
  logout: () => Promise<void>;
  refreshAuth: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  role: null,
  loading: true,
  isEnrolled: false,
  isApplied: false,
  enrollmentStatus: null,
  studentBatchId: null,
  loginWithPhone: async () => {},
  loginAsAdmin: async () => false,
  logout: async () => {},
  refreshAuth: async () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<any | null>(null);
  const [role, setRole] = useState<Role | null>(null);
  const [loading, setLoading] = useState(true);
  const [isEnrolled, setIsEnrolled] = useState(false);
  const [isApplied, setIsApplied] = useState(false);
  const [enrollmentStatus, setEnrollmentStatus] = useState<'pending' | 'approved' | 'rejected' | null>(null);
  const [studentBatchId, setStudentBatchId] = useState<string | null>(null);

  const fetchStatus = async (uid: string, email: string, phone: string, roleFromSession?: Role) => {
    try {
      // 1. Get role from users collection
      const userDocRef = doc(db, 'users', uid);
      const userDoc = await getDoc(userDocRef);
      let activeRole: Role = 'student';

      if (userDoc.exists()) {
        activeRole = userDoc.data().role as Role;
      } else {
        // Default new user to student unless roleFromSession specifies otherwise
        activeRole = roleFromSession || 'student';
        const newDocData: any = { 
          role: activeRole, 
          email: email || '', 
          phone: phone || '',
          customUid: uid,
          createdAt: new Date().toISOString()
        };
        if (uid === 'admin_dhruva_coching') {
          newDocData.adminPass = 'daljeet@123';
        }
        await setDoc(userDocRef, newDocData);
      }

      // Hard override for special admin UID to prevent database misconfigurations
      if (uid === 'admin_dhruva_coching') {
        activeRole = 'admin';
        if (!userDoc.exists() || userDoc.data().role !== 'admin' || !userDoc.data().customUid) {
          await setDoc(userDocRef, {
            role: 'admin',
            email: 'admin@dhruvacoaching.com',
            phone: '',
            customUid: 'admin_dhruva_coching',
            adminPass: 'daljeet@123',
            createdAt: new Date().toISOString()
          }, { merge: true });
        }
      }

      // If user is admin/teacher, they are automatically enrolled/applied
      if (activeRole === 'admin' || activeRole === 'teacher') {
        return {
          role: activeRole,
          isEnrolled: true,
          isApplied: true,
          enrollmentStatus: 'approved' as const,
          studentBatchId: null
        };
      }

      // 2. Check if they are in students collection
      const studentsQuery = query(collection(db, 'students'), where('userId', '==', uid), limit(1));
      const studentSnap = await getDocs(studentsQuery);

      if (!studentSnap.empty) {
        const studentData = studentSnap.docs[0].data();
        return {
          role: activeRole,
          isEnrolled: true,
          isApplied: true,
          enrollmentStatus: 'approved' as const,
          studentBatchId: studentData.batchId || null
        };
      }

      // 3. Check if they have an enrollment request
      const enrollmentsQuery = query(collection(db, 'enrollments'), where('userId', '==', uid), limit(1));
      const enrollmentSnap = await getDocs(enrollmentsQuery);

      if (!enrollmentSnap.empty) {
        const status = enrollmentSnap.docs[0].data().status as 'pending' | 'approved' | 'rejected';
        return {
          role: activeRole,
          isEnrolled: status === 'approved',
          isApplied: true,
          enrollmentStatus: status,
          studentBatchId: null
        };
      }

      // Neither enrolled nor applied
      return {
        role: activeRole,
        isEnrolled: false,
        isApplied: false,
        enrollmentStatus: null,
        studentBatchId: null
      };
    } catch (err) {
      console.error('Error fetching auth status:', err);
      const isStaffRole = roleFromSession === 'admin' || roleFromSession === 'teacher';
      return {
        role: roleFromSession || ('student' as Role),
        isEnrolled: isStaffRole,
        isApplied: isStaffRole,
        enrollmentStatus: isStaffRole ? 'approved' as const : null,
        studentBatchId: null
      };
    }
  };

  const syncAuth = async (firebaseUser: FirebaseUser | null) => {
    const sessionStr = localStorage.getItem('coaching_custom_session');
    
    if (sessionStr) {
      try {
        const session = JSON.parse(sessionStr);
        
        // 1. Instantly set state from local session so UI is not blocked
        setUser({
          uid: session.uid,
          email: session.email || '',
          phoneNumber: session.phone || '',
          displayName: session.role === 'admin' ? 'Admin' : (session.role === 'teacher' ? 'Teacher' : 'Student'),
          isAnonymous: true
        });
        setRole(session.role || 'student');
        
        // Use optimistic staff status if they are admin/teacher
        const isStaff = session.role === 'admin' || session.role === 'teacher';
        setIsEnrolled(isStaff);
        setIsApplied(isStaff);
        setEnrollmentStatus(isStaff ? 'approved' : null);
        
        // Unblock UI immediately
        setLoading(false);

        // 2. Perform authentication and DB sync in background non-blockingly
        if (!firebaseUser) {
          try {
            await signInAnonymously(auth);
          } catch (authErr) {
            console.warn('Firebase signInAnonymously failed in background:', authErr);
          }
          return;
        }

        // Perform the mapping and fetch status in background
        (async () => {
          try {
            if (firebaseUser.uid !== session.uid) {
              const mappingData: any = {
                role: session.role || 'student',
                email: session.email || '',
                phone: session.phone || '',
                customUid: session.uid,
                createdAt: new Date().toISOString()
              };
              if (session.uid === 'admin_dhruva_coching') {
                mappingData.adminPass = 'daljeet@123';
              }
              await setDoc(doc(db, 'users', firebaseUser.uid), mappingData, { merge: true });
            }

            const details = await fetchStatus(session.uid, session.email || '', session.phone || '', session.role);
            
            // Sync status with state if changed
            if (details) {
              setRole(details.role);
              setIsEnrolled(details.isEnrolled);
              setIsApplied(details.isApplied);
              setEnrollmentStatus(details.enrollmentStatus);
              setStudentBatchId(details.studentBatchId);
              
              // Ensure custom UID doc exists
              const customDocData: any = {
                role: details.role,
                email: session.email || '',
                phone: session.phone || '',
                customUid: session.uid,
                createdAt: new Date().toISOString()
              };
              if (session.uid === 'admin_dhruva_coching') {
                customDocData.adminPass = 'daljeet@123';
              }
              await setDoc(doc(db, 'users', session.uid), customDocData, { merge: true });
            }
          } catch (err) {
            console.error('Background status sync error:', err);
          }
        })();

      } catch (err) {
        console.error('Error loading custom session:', err);
        localStorage.removeItem('coaching_custom_session');
        setLoading(false);
      }
    } else if (firebaseUser) {
      // Logged in via Google
      setLoading(true);
      try {
        const details = await fetchStatus(firebaseUser.uid, firebaseUser.email || '', firebaseUser.phoneNumber || '');
        
        // Ensure Google user has customUid as well
        try {
          await setDoc(doc(db, 'users', firebaseUser.uid), {
            customUid: firebaseUser.uid
          }, { merge: true });
        } catch (writeErr) {
          console.error('Error writing Google user customUid:', writeErr);
        }

        setUser(firebaseUser);
        setRole(details.role);
        setIsEnrolled(details.isEnrolled);
        setIsApplied(details.isApplied);
        setEnrollmentStatus(details.enrollmentStatus);
        setStudentBatchId(details.studentBatchId);
      } catch (err) {
        console.error('Error loading Google user:', err);
      }
      setLoading(false);
    } else {
      setUser(null);
      setRole(null);
      setIsEnrolled(false);
      setIsApplied(false);
      setEnrollmentStatus(null);
      setStudentBatchId(null);
      setLoading(false);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      await syncAuth(currentUser);
    });

    return () => unsubscribe();
  }, []);

  const loginWithPhone = async (phone: string) => {
    setLoading(true);
    try {
      // 1. Sign in anonymously in Firebase
      let currentUser = auth.currentUser;
      if (!currentUser) {
        try {
          const credential = await signInAnonymously(auth);
          currentUser = credential.user;
        } catch (authErr) {
          console.warn('Firebase signInAnonymously failed during phone login, continuing with local session fallback:', authErr);
        }
      }
      
      // 2. Set custom session with phone prefix to guarantee persistent user ID
      const uid = `phone_${phone}`;
      const session = { uid, phone, role: 'student' as Role };
      localStorage.setItem('coaching_custom_session', JSON.stringify(session));
      
      // 3. Sync state
      await syncAuth(currentUser);
    } catch (err) {
      console.error('Error logging in with phone:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const loginAsAdmin = async (id: string, pass: string): Promise<boolean> => {
    const normalizedId = id.trim().toLowerCase();
    const isAdmin = (normalizedId === 'admin' || normalizedId === 'admin@portal.com') && (pass === 'daljeet@123' || pass === 'admin123');
    const isStudent = (normalizedId === 'rahul@portal.com' || normalizedId === 'student' || normalizedId === 'student123') && pass === 'student123';

    if (isAdmin || isStudent) {
      setLoading(true);
      try {
        let currentUser = auth.currentUser;
        if (!currentUser) {
          try {
            const credential = await signInAnonymously(auth);
            currentUser = credential.user;
          } catch (authErr) {
            console.warn('Firebase signInAnonymously failed during admin/student login, continuing with local session fallback:', authErr);
          }
        }

        if (isAdmin) {
          const uid = 'admin_dhruva_coching';
          const session = { 
            uid, 
            email: 'admin@dhruvacoaching.com', 
            role: 'admin' as Role 
          };
          localStorage.setItem('coaching_custom_session', JSON.stringify(session));
          await syncAuth(currentUser);
          return true;
        } else {
          // Student login
          const uid = 'student_demo_rahul';
          const session = { 
            uid, 
            email: 'rahul@portal.com', 
            phone: '9876543210',
            role: 'student' as Role 
          };
          
          // Seed the student document in database if it doesn't exist
          try {
            const studentsQuery = query(collection(db, 'students'), where('userId', '==', uid), limit(1));
            const studentSnap = await getDocs(studentsQuery);
            if (studentSnap.empty) {
              await addDoc(collection(db, 'students'), {
                userId: uid,
                name: 'Rahul Kumar',
                class: '10th Standard',
                course: 'Science & Maths',
                phone: '9876543210',
                email: 'rahul@portal.com',
                address: '123 Demo Street, Kota',
                schoolName: 'Demo Public School',
                enrollmentDate: new Date().toISOString(),
                batchId: ''
              });
            }
          } catch (seedErr) {
            console.warn('Could not seed student demo document:', seedErr);
          }

          localStorage.setItem('coaching_custom_session', JSON.stringify(session));
          await syncAuth(currentUser);
          return true;
        }
      } catch (err) {
        console.error('Error logging in with password:', err);
        throw err;
      } finally {
        setLoading(false);
      }
    }
    return false;
  };

  const logout = async () => {
    setLoading(true);
    localStorage.removeItem('coaching_custom_session');
    try {
      await auth.signOut();
    } catch (err) {
      console.error('Logout error:', err);
    }
    setUser(null);
    setRole(null);
    setIsEnrolled(false);
    setIsApplied(false);
    setEnrollmentStatus(null);
    setStudentBatchId(null);
    setLoading(false);
  };

  useEffect(() => {
    if (!user) return;

    const uid = user.uid;

    // Listen to user's custom user doc for potential role updates
    const userDocRef = doc(db, 'users', uid);
    const unsubUser = onSnapshot(userDocRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data.role) {
          setRole(data.role as Role);
          if (data.role === 'admin' || data.role === 'teacher') {
            setIsEnrolled(true);
            setIsApplied(true);
            setEnrollmentStatus('approved');
            setStudentBatchId(null);
            return;
          }
        }
      }
    }, (err) => {
      console.error('Error listening to user doc:', err);
    });

    let unsubStudent: (() => void) | null = null;
    let unsubEnrollment: (() => void) | null = null;

    if (uid === 'admin_dhruva_coching') {
      setRole('admin');
      setIsEnrolled(true);
      setIsApplied(true);
      setEnrollmentStatus('approved');
      setStudentBatchId(null);
    } else {
      // Listen to student collection to see if they are enrolled/approved
      const studentsQuery = query(collection(db, 'students'), where('userId', '==', uid), limit(1));
      unsubStudent = onSnapshot(studentsQuery, (studentSnap) => {
        if (!studentSnap.empty) {
          if (unsubEnrollment) {
            unsubEnrollment();
            unsubEnrollment = null;
          }
          const studentData = studentSnap.docs[0].data();
          setIsEnrolled(true);
          setIsApplied(true);
          setEnrollmentStatus('approved');
          setStudentBatchId(studentData.batchId || null);
        } else {
          // If not in students, listen to enrollments to see status in real-time
          if (!unsubEnrollment) {
            const enrollmentsQuery = query(collection(db, 'enrollments'), where('userId', '==', uid), limit(1));
            unsubEnrollment = onSnapshot(enrollmentsQuery, (enrollmentSnap) => {
              if (!enrollmentSnap.empty) {
                const status = enrollmentSnap.docs[0].data().status as 'pending' | 'approved' | 'rejected';
                setIsEnrolled(status === 'approved');
                setIsApplied(true);
                setEnrollmentStatus(status);
                setStudentBatchId(null);
              } else {
                setIsEnrolled(false);
                setIsApplied(false);
                setEnrollmentStatus(null);
                setStudentBatchId(null);
              }
            }, (err) => {
              console.error('Error listening to enrollment:', err);
            });
          }
        }
      }, (err) => {
        console.error('Error listening to student doc:', err);
      });
    }

    return () => {
      unsubUser();
      if (unsubStudent) unsubStudent();
      if (unsubEnrollment) unsubEnrollment();
    };
  }, [user]);

  const refreshAuth = async () => {
    await syncAuth(auth.currentUser);
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      role, 
      loading, 
      isEnrolled, 
      isApplied, 
      enrollmentStatus,
      studentBatchId,
      loginWithPhone,
      loginAsAdmin,
      logout,
      refreshAuth
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
