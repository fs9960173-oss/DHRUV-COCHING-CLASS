import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, addDoc, updateDoc, deleteDoc, doc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { useAuth } from './AuthContext';
import { Batch, Teacher, Student } from './types';
import { Calendar, Users, Clock, Plus, X, Trash2, Edit2, BookOpen, Layers } from 'lucide-react';

export default function Batches() {
  const { role, user } = useAuth();
  const [batches, setBatches] = useState<Batch[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [courses, setCourses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingBatch, setEditingBatch] = useState<any | null>(null);

  const isStaff = role === 'admin' || role === 'teacher';

  const fetchData = async () => {
    try {
      setLoading(true);
      const bSnap = await getDocs(collection(db, 'batches'));
      const tSnap = await getDocs(collection(db, 'teachers'));
      const sSnap = await getDocs(collection(db, 'students'));
      const cSnap = await getDocs(collection(db, 'courses'));

      const fetchedBatches = bSnap.docs.map(d => ({ id: d.id, ...d.data() } as any));
      const fetchedTeachers = tSnap.docs.map(d => ({ id: d.id, ...d.data() } as Teacher));
      const fetchedStudents = sSnap.docs.map(d => ({ id: d.id, ...d.data() } as Student));
      const fetchedCourses = cSnap.docs.map(d => ({ id: d.id, ...d.data() }));

      setTeachers(fetchedTeachers);
      setStudents(fetchedStudents);
      setCourses(fetchedCourses);

      if (!isStaff && user) {
        // If student, find their specific student profile and matching class/batch or filter
        const studentProfile = fetchedStudents.find(s => s.userId === user.uid);
        if (studentProfile) {
          // Filter batches that correspond to student's class
          setBatches(fetchedBatches.filter(b => b.class === studentProfile.class));
        } else {
          setBatches([]);
        }
      } else {
        setBatches(fetchedBatches);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'batches');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [role, user]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const selectedCourseName = fd.get('courseName') as string;

    const batchData = {
      name: fd.get('name') as string,
      class: selectedCourseName || 'General',
      courseName: selectedCourseName || '',
      teacherName: fd.get('teacherName') as string,
      startDate: fd.get('startDate') as string,
      endDate: fd.get('endDate') as string,
      timing: fd.get('timing') as string,
      description: fd.get('description') as string,
      image: (fd.get('image') as string) || 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&q=80&w=400',
      createdAt: new Date().toISOString(),
      classDays: ['Mon', 'Wed', 'Fri']
    };

    try {
      if (editingBatch && editingBatch.id) {
        await updateDoc(doc(db, 'batches', editingBatch.id), batchData);
      } else {
        await addDoc(collection(db, 'batches'), batchData);
      }
      setShowForm(false);
      setEditingBatch(null);
      fetchData();
    } catch (err) {
      handleFirestoreError(err, editingBatch ? OperationType.UPDATE : OperationType.CREATE, 'batches');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this batch?')) return;
    try {
      await deleteDoc(doc(db, 'batches', id));
      fetchData();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'batches');
    }
  };

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-24 bg-slate-200 rounded-3xl" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-64 bg-slate-200 rounded-2xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-12">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-indigo-600 via-indigo-700 to-slate-900 p-8 rounded-3xl text-white shadow-xl relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.1),transparent)]" />
        <div className="space-y-2 relative z-10">
          <span className="bg-indigo-500/30 border border-indigo-400/30 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">Dhruv Classrooms</span>
          <h1 className="text-3xl font-extrabold tracking-tight">Active Batches & Schedule</h1>
          <p className="text-indigo-200 text-sm max-w-xl">
            {isStaff ? 'Create and coordinate premium study cohorts, schedule lecture timings, and assign dedicated teachers.' : 'Access your current assigned batches, batch mates, study timings, and class days.'}
          </p>
        </div>
        {isStaff && (
          <button
            onClick={() => { setEditingBatch(null); setShowForm(true); }}
            className="self-start md:self-auto px-6 py-3 bg-white text-indigo-700 hover:bg-slate-100 transition-colors font-bold rounded-2xl shadow-lg flex items-center gap-2 relative z-10 animate-scaleIn"
          >
            <Plus className="w-5 h-5" /> Add New Batch
          </button>
        )}
      </div>

      {/* Batch Form Dialog (Add/Edit) */}
      {showForm && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-md flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden border border-slate-100 animate-scaleIn">
            <div className="flex items-center justify-between px-6 py-5 border-b border-slate-100 bg-indigo-50/50">
              <h3 className="font-extrabold text-lg text-slate-950 flex items-center gap-2">
                <Layers className="w-5 h-5 text-indigo-600" />
                {editingBatch ? 'Edit Batch' : 'Add Batch'}
              </h3>
              <button onClick={() => { setShowForm(false); setEditingBatch(null); }} className="text-slate-400 hover:text-slate-600 p-1.5 hover:bg-slate-100 rounded-full transition-colors cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Batch Name</label>
                <input required name="name" type="text" defaultValue={editingBatch?.name} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10 outline-none text-slate-900 font-medium text-sm placeholder-slate-400" placeholder="e.g. Achievers Batch 2026" />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Course</label>
                <select required name="courseName" defaultValue={editingBatch?.courseName || editingBatch?.class} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10 outline-none text-slate-900 font-medium text-sm bg-white">
                  <option value="">Select Course</option>
                  {courses.map(c => (
                    <option key={c.id} value={c.name}>{c.name}</option>
                  ))}
                  {courses.length === 0 && (
                    <>
                      <option value="JEE Advanced 2026">JEE Advanced 2026</option>
                      <option value="NEET 2026 Foundation">NEET 2026 Foundation</option>
                    </>
                  )}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Teacher</label>
                <input required name="teacherName" type="text" defaultValue={editingBatch?.teacherName} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10 outline-none text-slate-900 font-medium text-sm placeholder-slate-400" placeholder="Prof. R. Sharma" />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Image URL</label>
                <input name="image" type="url" defaultValue={editingBatch?.image} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10 outline-none text-slate-900 font-medium text-sm placeholder-slate-400" placeholder="https://unsplash.com/..." />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Start Date</label>
                  <input required name="startDate" type="date" defaultValue={editingBatch?.startDate} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10 outline-none text-slate-900 font-medium text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">End Date</label>
                  <input required name="endDate" type="date" defaultValue={editingBatch?.endDate} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10 outline-none text-slate-900 font-medium text-sm" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Timing (e.g., 6-9 PM)</label>
                <input required name="timing" type="text" defaultValue={editingBatch?.timing} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10 outline-none text-slate-900 font-medium text-sm placeholder-slate-400" placeholder="e.g., 6-9 PM" />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-1.5">Description</label>
                <textarea name="description" defaultValue={editingBatch?.description} rows={3} className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10 outline-none text-slate-900 font-medium text-sm placeholder-slate-400 resize-none" placeholder="Enter batch description..." />
              </div>

              <div className="pt-4 flex justify-end gap-3 border-t border-slate-100">
                <button type="button" onClick={() => { setShowForm(false); setEditingBatch(null); }} className="px-5 py-2.5 text-slate-600 font-bold hover:bg-slate-50 rounded-xl transition-colors cursor-pointer">Cancel</button>
                <button type="submit" className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-md cursor-pointer">
                  {editingBatch ? 'Save' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Grid List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {batches.length === 0 ? (
          <div className="col-span-full py-16 text-center bg-white rounded-3xl border border-slate-200 shadow-sm">
            <Layers className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-slate-900">No active batches</h3>
            <p className="text-slate-500 max-w-md mx-auto mt-1">There are no batches configured for this target class or section yet.</p>
          </div>
        ) : (
          batches.map(batch => {
            const batchStudents = students.filter(s => s.class === batch.class);
            return (
              <div key={batch.id} className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-xl hover:border-slate-300 transition-all flex flex-col group">
                <div className="h-44 relative bg-slate-900 overflow-hidden">
                  <img 
                    src={batch.image || 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&q=80&w=400'} 
                    alt={batch.name} 
                    className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-slate-950/20" />
                  <div className="absolute top-4 left-4">
                    <span className="bg-indigo-600 text-white font-extrabold text-xs px-2.5 py-1 rounded-lg shadow-md uppercase tracking-wider">
                      {batch.class}
                    </span>
                  </div>
                  {isStaff && (
                    <div className="absolute top-4 right-4 flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => { setEditingBatch(batch); setShowForm(true); }}
                        className="p-2 bg-white/90 hover:bg-white text-slate-800 rounded-xl shadow-lg transition-colors"
                        title="Edit Batch"
                      >
                        <Edit2 className="w-4 h-4 text-indigo-600" />
                      </button>
                      <button 
                        onClick={() => handleDelete(batch.id!)}
                        className="p-2 bg-white/90 hover:bg-red-50 text-red-600 rounded-xl shadow-lg transition-colors"
                        title="Delete Batch"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="font-extrabold text-xl text-white tracking-tight leading-snug drop-shadow-md">{batch.name}</h3>
                  </div>
                </div>

                {/* Batch Specifications */}
                <div className="p-5 flex-1 space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <Clock className="w-4 h-4 text-indigo-500 shrink-0" />
                      <div>
                        <div className="text-[10px] uppercase font-bold text-slate-400">Timing</div>
                        <div className="font-bold text-slate-800 text-xs truncate">{batch.timing}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <Users className="w-4 h-4 text-indigo-500 shrink-0" />
                      <div>
                        <div className="text-[10px] uppercase font-bold text-slate-400">Classmates</div>
                        <div className="font-bold text-slate-800 text-xs">{batchStudents.length} Assigned</div>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-indigo-100 text-indigo-700 font-bold text-xs rounded-xl flex items-center justify-center">
                        {batch.teacherName[0]}
                      </div>
                      <div className="text-xs">
                        <div className="text-[9px] uppercase font-bold text-slate-400">Mentor</div>
                        <div className="font-bold text-slate-800">{batch.teacherName}</div>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      {batch.classDays.map(d => (
                        <span key={d} className="bg-white px-2 py-0.5 border border-slate-200 text-[10px] font-bold text-slate-600 rounded-lg">
                          {d}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Timeline status */}
                <div className="px-5 py-3 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between text-xs text-slate-500 rounded-b-3xl">
                  <div className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>Start: {new Date(batch.startDate).toLocaleDateString([], { month: 'short', year: 'numeric' })}</span>
                  </div>
                  <span>End: {new Date(batch.endDate).toLocaleDateString([], { month: 'short', year: 'numeric' })}</span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
