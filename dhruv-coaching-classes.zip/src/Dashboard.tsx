import React, { useEffect, useState } from 'react';
import { useAuth } from './AuthContext';
import { collection, query, where, getDocs, orderBy, limit, addDoc, deleteDoc, doc, onSnapshot } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { Fee, Attendance, Assignment, Student, Enrollment, Announcement, Lecture } from './types';
import { IndianRupee, Users, TrendingDown, BookOpen, AlertCircle, Megaphone, Trash2, Plus, X, Video, Calendar, PlayCircle, UserPlus } from 'lucide-react';
import { Link } from 'react-router';

export default function Dashboard() {
  const { role, user } = useAuth();

  if (role === 'admin' || role === 'teacher') {
    return <StaffDashboard />;
  }

  if (role === 'student') {
    return <StudentDashboard />;
  }

  return <div>Loading...</div>;
}

function AnnouncementsBoard({ isStaff }: { isStaff: boolean }) {
  const { user, role } = useAuth();
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);

  useEffect(() => {
    setLoading(true);
    const q = query(
      collection(db, 'announcements'), 
      orderBy('createdAt', 'desc'), 
      limit(role === 'student' ? 5 : 10)
    );
    const unsubscribe = onSnapshot(q, (snap) => {
      setAnnouncements(snap.docs.map(d => ({ id: d.id, ...d.data() } as Announcement)));
      setLoading(false);
    }, (error) => {
      console.error("Error listening to announcements in real-time:", error);
      setLoading(false);
      try {
        handleFirestoreError(error, OperationType.LIST, 'announcements');
      } catch (err) {
        console.error("Announcements onSnapshot error:", err);
      }
    });

    return () => unsubscribe();
  }, []);

  const handlePost = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user) return;
    const fd = new FormData(e.currentTarget);
    const newAnnouncement = {
      title: fd.get('title') as string,
      content: fd.get('content') as string,
      authorId: user.uid,
      authorName: user.displayName || user.email || 'Staff',
      createdAt: new Date().toISOString()
    };

    try {
      await addDoc(collection(db, 'announcements'), newAnnouncement);
      setShowAddForm(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'announcements');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this announcement?')) return;
    try {
      await deleteDoc(doc(db, 'announcements', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'announcements');
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
        <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <Megaphone className="w-5 h-5 text-indigo-600" />
          Global Announcements
        </h2>
        {isStaff && !showAddForm && (
          <button onClick={() => setShowAddForm(true)} className="text-sm font-medium text-indigo-600 hover:text-indigo-700 flex items-center gap-1">
            <Plus className="w-4 h-4" /> Post Update
          </button>
        )}
      </div>

      {showAddForm && isStaff && (
        <form onSubmit={handlePost} className="p-4 border-b border-slate-100 bg-indigo-50/30">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-sm text-slate-800">New Announcement</h3>
            <button type="button" onClick={() => setShowAddForm(false)} className="text-slate-400 hover:text-slate-600">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="space-y-3">
            <input required name="title" type="text" placeholder="Announcement Title" className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none" />
            <textarea required name="content" rows={3} placeholder="Write your message here..." className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none resize-none" />
            <div className="flex justify-end">
              <button type="submit" className="px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700">
                Post Announcement
              </button>
            </div>
          </div>
        </form>
      )}

      <div className="divide-y divide-slate-100">
        {loading ? (
          <div className="p-6 text-center text-sm text-slate-500">Loading announcements...</div>
        ) : announcements.length === 0 ? (
          <div className="p-6 text-center text-sm text-slate-500">No recent announcements.</div>
        ) : (
          announcements.map(ann => (
            <div key={ann.id} className="p-4 hover:bg-slate-50 transition-colors">
              <div className="flex justify-between items-start gap-4">
                <div>
                  <h3 className="font-bold text-slate-900">{ann.title}</h3>
                  <p className="text-sm text-slate-600 mt-1 whitespace-pre-wrap">{ann.content}</p>
                  <div className="flex items-center gap-2 mt-3 text-xs text-slate-500">
                    <span className="font-medium">By {ann.authorName}</span>
                    <span>•</span>
                    <span>{new Date(ann.createdAt).toLocaleDateString()} at {new Date(ann.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                </div>
                {isStaff && (role === 'admin' || ann.authorId === user?.uid) && (
                  <button onClick={() => handleDelete(ann.id!)} className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors shrink-0">
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function StaffDashboard() {
  const { role } = useAuth();
  const [stats, setStats] = useState({ revenue: 0, pendingFees: 0, studentCount: 0 });
  const [pendingEnrollmentsCount, setPendingEnrollmentsCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        const feesSnap = await getDocs(collection(db, 'fees'));
        let rev = 0;
        let pending = 0;
        feesSnap.forEach(doc => {
          const fee = doc.data() as Fee;
          if (fee.status === 'paid') rev += fee.amount;
          else pending += fee.amount;
        });

        const studentSnap = await getDocs(collection(db, 'students'));
        
        setStats({ revenue: rev, pendingFees: pending, studentCount: studentSnap.size });
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'fees/students');
      } finally {
        setLoading(false);
      }
    }
    fetchData();

    // Listen to pending enrollments in real-time
    const q = query(collection(db, 'enrollments'), where('status', '==', 'pending'));
    const unsubscribe = onSnapshot(q, (snap) => {
      setPendingEnrollmentsCount(snap.size);
    }, (error) => {
      console.error("Error listening to pending enrollments:", error);
    });

    return () => unsubscribe();
  }, []);

  if (loading) return <div>Loading dashboard...</div>;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-slate-900">Dashboard Overview</h1>

      {role === 'admin' && pendingEnrollmentsCount > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm animate-pulse">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="p-3 bg-amber-100 text-amber-700 rounded-xl shrink-0">
              <UserPlus className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-extrabold text-amber-950 text-base">Admission Requests Pending Approval</h4>
              <p className="text-sm text-amber-800 mt-1">
                There {pendingEnrollmentsCount === 1 ? 'is 1 student' : `are ${pendingEnrollmentsCount} students`} waiting for your approval to get access to the portal.
              </p>
            </div>
          </div>
          <Link 
            to="/enrollments" 
            className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl transition-all inline-flex items-center gap-2 shadow-sm shrink-0 self-start sm:self-auto"
          >
            Review and Approve / Cancel Requests &rarr;
          </Link>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title="Total Revenue" value={`₹${stats.revenue}`} icon={IndianRupee} color="text-green-600" bg="bg-green-100" />
        <StatCard title="Pending Fees" value={`₹${stats.pendingFees}`} icon={TrendingDown} color="text-red-600" bg="bg-red-100" />
        <StatCard title="Total Students" value={stats.studentCount.toString()} icon={Users} color="text-blue-600" bg="bg-blue-100" />
      </div>
      
      <div className="mt-8">
        <AnnouncementsBoard isStaff={true} />
      </div>
    </div>
  );
}

function StudentDashboard() {
  const { user, refreshAuth } = useAuth();
  const [studentInfo, setStudentInfo] = useState<Student | null>(null);
  const [enrollment, setEnrollment] = useState<Enrollment | null>(null);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [pendingFees, setPendingFees] = useState<Fee[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    setLoading(true);

    let unsubEnroll: (() => void) | null = null;

    // Listen to student info in real-time
    const studentQuery = query(collection(db, 'students'), where('userId', '==', user.uid), limit(1));
    const unsubStudent = onSnapshot(studentQuery, async (studentSnap) => {
      if (!studentSnap.empty) {
        if (unsubEnroll) {
          unsubEnroll();
          unsubEnroll = null;
        }
        const student = { id: studentSnap.docs[0].id, ...studentSnap.docs[0].data() } as Student;
        setStudentInfo(student);

        // Fetch assignments for their class/course
        try {
          const aq = query(collection(db, 'assignments'), where('class', '==', student.class), where('course', '==', student.course));
          const asnSnap = await getDocs(aq);
          setAssignments(asnSnap.docs.map(d => ({ id: d.id, ... (d.data() as any) } as Assignment)));

          // Fetch pending fees
          const fq = query(collection(db, 'fees'), where('studentId', '==', student.id), where('status', '==', 'pending'));
          const fSnap = await getDocs(fq);
          setPendingFees(fSnap.docs.map(d => ({ id: d.id, ... (d.data() as any) } as Fee)));
        } catch (err) {
          console.error("Error loading student secondary data:", err);
        }
        setLoading(false);
      } else {
        setStudentInfo(null);
        // Not a student yet, check enrollment status in real-time
        if (!unsubEnroll) {
          const enrollQuery = query(collection(db, 'enrollments'), where('userId', '==', user.uid), limit(1));
          unsubEnroll = onSnapshot(enrollQuery, (enrollSnap) => {
            if (!enrollSnap.empty) {
              setEnrollment({ id: enrollSnap.docs[0].id, ...enrollSnap.docs[0].data() } as Enrollment);
            } else {
              setEnrollment(null);
            }
            setLoading(false);
          }, (error) => {
            console.error("Error listening to enrollment:", error);
            setLoading(false);
          });
        }
      }
    }, (error) => {
      console.error("Error listening to student info:", error);
      setLoading(false);
    });

    return () => {
      unsubStudent();
      if (unsubEnroll) unsubEnroll();
    };
  }, [user]);

  const handleEnrollmentSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user) return;
    const fd = new FormData(e.currentTarget);
    const newEnrollment = {
      userId: user.uid,
      name: fd.get('name') as string,
      class: fd.get('class') as string,
      course: fd.get('course') as string,
      phone: fd.get('phone') as string,
      address: fd.get('address') as string,
      schoolName: fd.get('schoolName') as string,
      email: user.email || '',
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    try {
      const docRef = await addDoc(collection(db, 'enrollments'), newEnrollment);
      setEnrollment({ id: docRef.id, ...newEnrollment } as Enrollment);
      await refreshAuth();
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'enrollments');
    }
  };

  if (loading) return <div>Loading dashboard...</div>;

  if (!studentInfo) {
    if (enrollment && enrollment.status === 'pending') {
      return (
        <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-200 text-center max-w-2xl mx-auto mt-10">
          <div className="w-16 h-16 bg-yellow-100 text-yellow-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <TrendingDown className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">Enrollment Pending Approval</h2>
          <p className="text-slate-600">Your admission form has been submitted and is currently under review by the administration. You will be notified once approved.</p>
        </div>
      );
    }

    return (
      <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-200 max-w-2xl mx-auto mt-10">
        {enrollment && enrollment.status === 'rejected' && (
          <div className="mb-6 p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-sm flex items-start gap-3">
            <span className="text-lg">⚠️</span>
            <div>
              <p className="font-bold text-rose-900">Your previous admission request was rejected or cancelled.</p>
              <p className="text-xs mt-1 text-rose-700">Please review your contact details, class, and course selection, then correct and resubmit the form below for fresh admin approval.</p>
            </div>
          </div>
        )}
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-slate-900">Student Enrollment Form</h2>
          <p className="text-slate-600 mt-2">Fill out the form below to apply for admission.</p>
        </div>
        <form onSubmit={handleEnrollmentSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
            <input required name="name" type="text" className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none transition-shadow" placeholder="e.g. John Doe" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Class</label>
              <select required name="class" className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none bg-white">
                {[...Array(12)].map((_, i) => (
                  <option key={i+1} value={`Class ${i+1}`}>Class {i+1}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Course</label>
              <select required name="course" className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none bg-white">
                <option value="Mathematics">Mathematics</option>
                <option value="Science">Science</option>
                <option value="Crash Course">Crash Course</option>
                <option value="All Subjects">All Subjects</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
              <input required name="phone" type="tel" defaultValue={user?.phoneNumber || ''} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none transition-shadow" placeholder="+91 XXXXX XXXXX" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">School Name</label>
              <input required name="schoolName" type="text" className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none transition-shadow" placeholder="Your School Name" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Address</label>
            <textarea required name="address" rows={2} className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none transition-shadow resize-none" placeholder="Full Residential Address" />
          </div>
          <div className="pt-4">
            <button type="submit" className="w-full bg-indigo-600 text-white font-medium py-3 rounded-lg hover:bg-indigo-700 transition-colors shadow-sm">
              Submit Application
            </button>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {pendingFees.length > 0 && (
        <div className="space-y-3">
          {pendingFees.map(fee => {
            const dueDate = new Date(fee.dueDate);
            const today = new Date();
            const daysUntilDue = Math.ceil((dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
            
            const isOverdue = daysUntilDue < 0;
            const isApproaching = daysUntilDue >= 0 && daysUntilDue <= 7;
            
            if (!isOverdue && !isApproaching) return null;

            return (
              <div key={fee.id} className={`p-4 rounded-xl border flex items-start gap-4 shadow-sm ${isOverdue ? 'bg-red-50 border-red-200 text-red-900' : 'bg-yellow-50 border-yellow-200 text-yellow-900'}`}>
                <div className={`mt-0.5 ${isOverdue ? 'text-red-600' : 'text-yellow-600'}`}>
                  <AlertCircle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm">
                    {isOverdue ? 'Payment Overdue' : 'Payment Deadline Approaching'}
                  </h3>
                  <p className="text-sm mt-1 opacity-90">
                    Your fee payment of <span className="font-semibold">₹{fee.amount}</span> is {isOverdue ? 'overdue by ' + Math.abs(daysUntilDue) + ' days' : 'due in ' + daysUntilDue + ' days'} (Due: {dueDate.toLocaleDateString()}). Please make the payment as soon as possible.
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div>
        <h1 className="text-2xl font-bold text-slate-900 mb-6">Welcome back, {studentInfo.name}</h1>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 flex flex-col md:flex-row gap-6 items-start md:items-center">
          <div className="w-20 h-20 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center text-2xl font-bold">
            {studentInfo.name.charAt(0)}
          </div>
          <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <div className="text-sm text-slate-500">Class</div>
              <div className="font-medium text-slate-900">{studentInfo.class}</div>
            </div>
            <div>
              <div className="text-sm text-slate-500">Course</div>
              <div className="font-medium text-slate-900">{studentInfo.course}</div>
            </div>
            <div>
              <div className="text-sm text-slate-500">Phone</div>
              <div className="font-medium text-slate-900">{studentInfo.phone}</div>
            </div>
            <div>
              <div className="text-sm text-slate-500">Enrolled</div>
              <div className="font-medium text-slate-900">{new Date(studentInfo.enrollmentDate).toLocaleDateString()}</div>
            </div>
          </div>
        </div>
      </div>

      <AnnouncementsBoard isStaff={false} />
    </div>
  );
}

function StatCard({ title, value, icon: Icon, color, bg }: any) {
  return (
    <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
      <div className="text-slate-500 text-xs font-semibold uppercase tracking-wider mb-2 flex items-center gap-2">
        <Icon className="w-4 h-4" />
        {title}
      </div>
      <div className="text-2xl font-bold text-slate-900">{value}</div>
    </div>
  );
}

function UpcomingClassesWidget({ student }: { student: Student }) {
  const [lectures, setLectures] = useState<Lecture[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchLectures() {
      try {
        const q = query(collection(db, 'lectures'), orderBy('scheduledFor', 'desc'));
        const snap = await getDocs(q);
        const allLectures = snap.docs.map(d => ({ id: d.id, ...d.data() } as Lecture));
        
        // Filter by student class & course
        const filtered = allLectures.filter(l => l.class === student.class && (l.course === student.course || l.course === 'All Subjects'));
        setLectures(filtered.slice(0, 3)); // Only show top 3
      } catch (error) {
        console.error("Error fetching lectures:", error);
      } finally {
        setLoading(false);
      }
    }
    fetchLectures();
  }, [student]);

  if (loading || lectures.length === 0) return null;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-indigo-50">
        <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <Video className="w-5 h-5 text-indigo-600" />
          Live & Upcoming Classes
        </h2>
        <Link to="/lectures" className="text-sm font-medium text-indigo-600 hover:text-indigo-700">View All</Link>
      </div>
      <div className="divide-y divide-slate-100">
        {lectures.map(lecture => {
          const isUpcoming = new Date(lecture.scheduledFor) > new Date();
          return (
            <div key={lecture.id} className="p-4 hover:bg-slate-50 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                   <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full uppercase tracking-wider ${isUpcoming ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600'}`}>
                    {isUpcoming ? 'Upcoming' : 'Recorded'}
                  </span>
                  <span className="text-xs font-medium text-slate-500">{lecture.course}</span>
                </div>
                <h3 className="font-bold text-slate-900">{lecture.title}</h3>
                <div className="flex items-center gap-2 mt-1 text-xs text-slate-500">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>{new Date(lecture.scheduledFor).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}</span>
                </div>
              </div>
              <a
                href={lecture.videoUrl}
                target="_blank"
                rel="noreferrer"
                className={`shrink-0 flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${
                  isUpcoming 
                    ? 'bg-amber-100 text-amber-700 hover:bg-amber-200' 
                    : 'bg-indigo-600 text-white hover:bg-indigo-700'
                }`}
              >
                {isUpcoming ? 'Join Live' : (
                  <><PlayCircle className="w-4 h-4" /> Watch</>
                )}
              </a>
            </div>
          );
        })}
      </div>
    </div>
  );
}
