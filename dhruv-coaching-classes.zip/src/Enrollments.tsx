import React, { useEffect, useState } from 'react';
import { collection, getDocs, updateDoc, doc, addDoc, query, where, deleteDoc, onSnapshot } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { Enrollment } from './types';
import { Check, X as XIcon, Clock } from 'lucide-react';

export default function Enrollments() {
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [batches, setBatches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionError, setActionError] = useState<string | null>(null);

  const fetchBatches = async () => {
    try {
      const snap = await getDocs(collection(db, 'batches'));
      setBatches(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (error) {
      console.error('Error fetching batches:', error);
    }
  };

  useEffect(() => {
    fetchBatches();
    
    setLoading(true);
    const unsubscribe = onSnapshot(collection(db, 'enrollments'), (snap) => {
      setEnrollments(snap.docs.map(d => ({ id: d.id, ...d.data() } as Enrollment)));
      setLoading(false);
    }, (error) => {
      console.error("Error fetching enrollments in real-time:", error);
      setLoading(false);
      try {
        handleFirestoreError(error, OperationType.LIST, 'enrollments');
      } catch (err) {
        console.error("Enrollment onSnapshot error:", err);
      }
    });

    return () => unsubscribe();
  }, []);

  const handleApprove = async (enrollment: Enrollment) => {
    setActionError(null);
    try {
      // Find matching batch
      const matchingBatch = batches.find(b => b.class === enrollment.class);

      // 1. Add to students collection FIRST
      // This is safer because if this fails, we don't end up with an orphan approved enrollment status
      const newStudent = {
        userId: enrollment.userId || '',
        name: enrollment.name || '',
        class: enrollment.class || '',
        course: enrollment.course || '',
        phone: enrollment.phone || '',
        email: enrollment.email || '',
        address: enrollment.address || '',
        schoolName: enrollment.schoolName || '',
        enrollmentDate: new Date().toISOString(),
        batchId: (matchingBatch && matchingBatch.id) ? matchingBatch.id : ''
      };
      
      const studentRef = await addDoc(collection(db, 'students'), newStudent);

      // 2. Update enrollment status only after student is successfully created
      await updateDoc(doc(db, 'enrollments', enrollment.id!), { status: 'approved' });

      // 3. Generate fees
      const feeQuery = query(
        collection(db, 'courseFees'), 
        where('class', '==', newStudent.class),
        where('course', '==', newStudent.course)
      );
      const feeSnap = await getDocs(feeQuery);
      
      if (!feeSnap.empty) {
        const feeData = feeSnap.docs[0].data();
        const dueDate = new Date();
        dueDate.setMonth(dueDate.getMonth() + 1);
        
        await addDoc(collection(db, 'fees'), {
          studentId: studentRef.id,
          amount: feeData.amount || 0,
          status: 'pending',
          dueDate: dueDate.toISOString(),
          paymentDate: ''
        });
      }
    } catch (error: any) {
      console.error('Error in handleApprove:', error);
      setActionError(error instanceof Error ? error.message : String(error));
    }
  };

  const handleReject = async (id: string) => {
    setActionError(null);
    try {
      await updateDoc(doc(db, 'enrollments', id), { status: 'rejected' });
    } catch (error: any) {
      console.error('Error in handleReject:', error);
      setActionError(error instanceof Error ? error.message : String(error));
    }
  };

  if (loading) return <div className="text-center py-12 text-slate-500">Loading enrollments...</div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between sm:flex-row sm:items-center gap-4">
        <h1 className="text-2xl font-bold text-slate-900">Admission Requests</h1>
      </div>

      {actionError && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-800 rounded-xl text-sm font-medium">
          ⚠️ Action failed: {actionError}
        </div>
      )}

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-500 font-medium uppercase text-xs sticky top-0">
              <tr className="border-b border-slate-200">
                <th className="px-4 py-3">Applicant Name</th>
                <th className="px-4 py-3">Class & Course</th>
                <th className="px-4 py-3">Contact</th>
                <th className="px-4 py-3">Applied On</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {enrollments.length === 0 ? (
                <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-500">No enrollment requests found.</td></tr>
              ) : (
                enrollments.map(enrollment => (
                  <tr key={enrollment.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-4 py-3">
                      <div className="font-medium text-slate-900">{enrollment.name}</div>
                      <div className="text-xs text-slate-500 mt-0.5" title={enrollment.address}>{enrollment.schoolName}</div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="text-slate-900">{enrollment.class}</div>
                      <div className="text-xs text-slate-500 mt-0.5">{enrollment.course}</div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="text-slate-600">{enrollment.phone}</div>
                      <div className="text-xs text-slate-400">{enrollment.email}</div>
                    </td>
                    <td className="px-4 py-3 text-slate-600">
                      {new Date(enrollment.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3">
                      {enrollment.status === 'pending' && <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-medium bg-yellow-100 text-yellow-800 uppercase"><Clock className="w-3 h-3" /> Pending</span>}
                      {enrollment.status === 'approved' && <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-medium bg-green-100 text-green-800 uppercase"><Check className="w-3 h-3" /> Approved</span>}
                      {enrollment.status === 'rejected' && <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-medium bg-red-100 text-red-800 uppercase"><XIcon className="w-3 h-3" /> Rejected</span>}
                    </td>
                    <td className="px-4 py-3 text-right">
                      {enrollment.status === 'pending' && (
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleApprove(enrollment)}
                            className="p-1.5 text-green-600 hover:bg-green-50 rounded-md transition-colors"
                            title="Approve"
                          >
                            <Check className="w-5 h-5" />
                          </button>
                          <button
                            onClick={() => handleReject(enrollment.id!)}
                            className="p-1.5 text-red-600 hover:bg-red-50 rounded-md transition-colors"
                            title="Reject"
                          >
                            <XIcon className="w-5 h-5" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
