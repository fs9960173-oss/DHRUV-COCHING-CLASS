import React, { useEffect, useState } from 'react';
import { collection, getDocs, addDoc, query, where, updateDoc, doc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { Student, Fee, CourseFee } from './types';
import { useAuth } from './AuthContext';
import { Plus, X, IndianRupee, Settings } from 'lucide-react';

export default function Fees() {
  const { role, user } = useAuth();
  const [students, setStudents] = useState<Student[]>([]);
  const [fees, setFees] = useState<Fee[]>([]);
  const [courseFees, setCourseFees] = useState<CourseFee[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  const fetchCourseFees = async () => {
    try {
      const snap = await getDocs(collection(db, 'courseFees'));
      setCourseFees(snap.docs.map(d => ({ id: d.id, ... (d.data() as any) } as CourseFee)));
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    async function fetchData() {
      setLoading(true);
      try {
        if (role === 'student') {
          const sq = query(collection(db, 'students'), where('userId', '==', user?.uid || ''));
          const studentSnap = await getDocs(sq);
          if (!studentSnap.empty) {
            const studentId = studentSnap.docs[0].id;
            const mq = query(collection(db, 'fees'), where('studentId', '==', studentId));
            const feesSnap = await getDocs(mq);
            setFees(feesSnap.docs.map(d => ({ id: d.id, ... (d.data() as any) } as Fee)));
          }
        } else {
          const studentSnap = await getDocs(collection(db, 'students'));
          setStudents(studentSnap.docs.map(d => ({ id: d.id, ... (d.data() as any) } as Student)));

          const feesSnap = await getDocs(collection(db, 'fees'));
          setFees(feesSnap.docs.map(d => ({ id: d.id, ... (d.data() as any) } as Fee)));
          
          if (role === 'admin') {
            await fetchCourseFees();
          }
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'fees/students');
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, [role, user]);

  const handleAdd = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const newFee = {
      studentId: fd.get('studentId') as string,
      amount: Number(fd.get('amount')),
      status: 'pending' as const,
      dueDate: fd.get('dueDate') as string,
      paymentDate: '',
    };

    try {
      const docRef = await addDoc(collection(db, 'fees'), newFee);
      setShowAddModal(false);
      setFees(prev => [...prev, { id: docRef.id, ...newFee }]);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'fees');
    }
  };

  const handleAddCourseFee = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const newCourseFee = {
      class: fd.get('class') as string,
      course: fd.get('course') as string,
      amount: Number(fd.get('amount')),
    };

    try {
      await addDoc(collection(db, 'courseFees'), newCourseFee);
      await fetchCourseFees();
      (e.target as HTMLFormElement).reset();
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'courseFees');
    }
  };

  const markAsPaid = async (feeId: string) => {
    try {
      await updateDoc(doc(db, 'fees', feeId), {
        status: 'paid',
        paymentDate: new Date().toISOString()
      });
      setFees(prev => prev.map(f => f.id === feeId ? { ...f, status: 'paid', paymentDate: new Date().toISOString() } : f));
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `fees/${feeId}`);
    }
  };

  if (role === 'student') {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-slate-900">My Fees</h1>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 font-medium uppercase text-xs sticky top-0">
                <tr className="border-b border-slate-200">
                  <th className="px-4 py-3">Amount</th>
                  <th className="px-4 py-3">Due Date</th>
                  <th className="px-4 py-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {fees.length === 0 ? (
                  <tr><td colSpan={3} className="px-4 py-8 text-center text-slate-500">No fee records.</td></tr>
                ) : (
                  fees.map(f => (
                    <tr key={f.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3 font-bold text-slate-900">₹{f.amount}</td>
                      <td className="px-4 py-3 text-slate-600">{new Date(f.dueDate).toLocaleDateString()}</td>
                      <td className="px-4 py-3">
                        {f.status === 'paid' ? (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-green-100 text-green-800 uppercase">Paid on {new Date(f.paymentDate).toLocaleDateString()}</span>
                        ) : (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-red-100 text-red-800 uppercase">Pending</span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <h1 className="text-2xl font-bold text-slate-900">Fees Management</h1>
        <div className="flex items-center gap-2">
          {role === 'admin' && (
            <button 
              onClick={() => setShowSettingsModal(true)}
              className="flex items-center justify-center gap-2 bg-white text-slate-700 border border-slate-300 px-4 py-2 rounded-lg font-medium hover:bg-slate-50 transition-colors"
            >
              <Settings className="w-4 h-4" />
              Configure Fees
            </button>
          )}
          <button 
            onClick={() => setShowAddModal(true)}
            className="flex items-center justify-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Fee Record
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-500">Loading...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 font-medium uppercase text-xs sticky top-0">
                <tr className="border-b border-slate-200">
                  <th className="px-4 py-3">Student</th>
                  <th className="px-4 py-3">Amount</th>
                  <th className="px-4 py-3">Due Date</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {fees.length === 0 ? (
                  <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-500">No fee records found.</td></tr>
                ) : (
                  fees.map(f => {
                    const s = students.find(s => s.id === f.studentId);
                    return (
                      <tr key={f.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-4 py-3 font-medium text-slate-900">{s?.name || 'Unknown'}</td>
                        <td className="px-4 py-3 font-bold text-slate-900">₹{f.amount}</td>
                        <td className="px-4 py-3 text-slate-600">{new Date(f.dueDate).toLocaleDateString()}</td>
                        <td className="px-4 py-3">
                          {f.status === 'paid' ? (
                            <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-green-100 text-green-800 uppercase">Paid</span>
                          ) : (
                            <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-red-100 text-red-800 uppercase">Pending</span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-right">
                          {f.status === 'pending' && (
                            <button 
                              onClick={() => markAsPaid(f.id!)}
                              className="text-sm font-medium text-indigo-600 hover:text-indigo-900"
                            >
                              Mark Paid
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showSettingsModal && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 shrink-0">
              <h3 className="font-bold text-lg text-slate-900">Configure Auto Fees</h3>
              <button onClick={() => setShowSettingsModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto">
              <form onSubmit={handleAddCourseFee} className="bg-slate-50 p-4 rounded-xl border border-slate-200 mb-6 flex flex-col sm:flex-row gap-4 items-end">
                <div className="flex-1 w-full">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Class</label>
                  <select required name="class" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-sm">
                    <option value="Class 10">Class 10</option>
                    <option value="Class 11">Class 11</option>
                    <option value="Class 12">Class 12</option>
                  </select>
                </div>
                <div className="flex-1 w-full">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Course</label>
                  <select required name="course" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-sm">
                    <option value="Mathematics">Mathematics</option>
                    <option value="Science">Science</option>
                    <option value="Crash Course">Crash Course</option>
                  </select>
                </div>
                <div className="flex-1 w-full">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Fee (₹)</label>
                  <input required name="amount" type="number" min="0" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-sm" placeholder="e.g. 5000" />
                </div>
                <button type="submit" className="px-4 py-2 bg-slate-900 text-white text-sm font-medium rounded-lg hover:bg-slate-800 shrink-0 w-full sm:w-auto">
                  Set Fee
                </button>
              </form>

              <h4 className="font-semibold text-slate-800 mb-3 text-sm">Configured Fees</h4>
              <div className="border border-slate-200 rounded-lg overflow-hidden">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 text-slate-500 font-medium uppercase text-xs">
                    <tr className="border-b border-slate-200">
                      <th className="px-4 py-2">Class</th>
                      <th className="px-4 py-2">Course</th>
                      <th className="px-4 py-2">Fee Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {courseFees.length === 0 ? (
                      <tr><td colSpan={3} className="px-4 py-4 text-center text-slate-500">No course fees configured.</td></tr>
                    ) : (
                      courseFees.map(cf => (
                        <tr key={cf.id} className="hover:bg-slate-50">
                          <td className="px-4 py-2 font-medium">{cf.class}</td>
                          <td className="px-4 py-2 text-slate-600">{cf.course}</td>
                          <td className="px-4 py-2 font-bold">₹{cf.amount}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
              <h3 className="font-bold text-lg text-slate-900">Add Fee Record</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAdd} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Student</label>
                <select required name="studentId" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none">
                  <option value="">Select Student</option>
                  {students.map(s => <option key={s.id} value={s.id}>{s.name} ({s.class})</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Amount (₹)</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <IndianRupee className="w-4 h-4" />
                  </div>
                  <input required name="amount" type="number" min="0" className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="5000" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Due Date</label>
                <input required name="dueDate" type="date" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
              </div>
              <div className="pt-4 flex justify-end gap-3">
                <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 text-slate-600 font-medium hover:bg-slate-50 rounded-lg">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700">Add Record</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
