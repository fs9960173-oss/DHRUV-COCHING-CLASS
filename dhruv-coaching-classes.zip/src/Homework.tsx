import React, { useState, useEffect } from 'react';
import { collection, getDocs, addDoc, deleteDoc, doc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { useAuth } from './AuthContext';
import { Trash2, Plus, X, ClipboardList } from 'lucide-react';

interface HomeworkItem {
  id?: string;
  title: string;
  subject: string;
  deadline: string;
  marks: number;
  batchName?: string;
  description?: string;
}

const DEFAULT_HOMEWORK = [
  { title: 'Cell Structure Diagrams', subject: 'Biology', deadline: '2026-07-17', marks: 30, batchName: 'NEET 2026 Foundation', description: 'Draw and label the ultra-structure of plant and animal cells.' },
  { title: 'Kinematics Problem Set', subject: 'Physics', deadline: '2026-07-18', marks: 50, batchName: 'JEE Advanced 2026', description: 'Solve problems 1-15 on projectile motion and relative velocity.' }
];

export default function Homework() {
  const { role } = useAuth();
  const [homeworkList, setHomeworkList] = useState<HomeworkItem[]>([]);
  const [batches, setBatches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);

  // Form states
  const [newTitle, setNewTitle] = useState('');
  const [newSubject, setNewSubject] = useState('');
  const [newDeadline, setNewDeadline] = useState('');
  const [newMarks, setNewMarks] = useState(100);
  const [newBatch, setNewBatch] = useState('');
  const [newDescription, setNewDescription] = useState('');

  const isStaff = role === 'admin' || role === 'teacher';

  const fetchHomework = async () => {
    try {
      setLoading(true);
      const snap = await getDocs(collection(db, 'homework_simple'));
      let fetched = snap.docs.map(d => ({ id: d.id, ...d.data() } as HomeworkItem));

      const bSnap = await getDocs(collection(db, 'batches'));
      const fetchedBatches = bSnap.docs.map(d => ({ id: d.id, ...d.data() } as any));
      setBatches(fetchedBatches);
      if (fetchedBatches.length > 0) {
        setNewBatch(fetchedBatches[0].name || fetchedBatches[0].class);
      } else {
        setNewBatch('JEE Advanced 2026');
      }

      if (fetched.length === 0) {
        // Auto-seed
        for (const item of DEFAULT_HOMEWORK) {
          const docRef = await addDoc(collection(db, 'homework_simple'), item);
          fetched.push({ id: docRef.id, ...item });
        }
      }

      setHomeworkList(fetched);
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'homework_simple');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHomework();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDeadline || !newSubject.trim()) return;

    const newItem = {
      title: newTitle.trim(),
      subject: newSubject.trim(),
      deadline: newDeadline,
      marks: Number(newMarks),
      batchName: newBatch,
      description: newDescription.trim()
    };

    try {
      await addDoc(collection(db, 'homework_simple'), newItem);
      setNewTitle('');
      setNewSubject('');
      setNewDescription('');
      setNewMarks(100);
      setShowAddForm(false);
      fetchHomework();
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'homework_simple');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this homework?')) return;
    try {
      await deleteDoc(doc(db, 'homework_simple', id));
      fetchHomework();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'homework_simple');
    }
  };

  if (loading) {
    return (
      <div className="min-h-[400px] flex flex-col items-center justify-center font-sans">
        <div className="w-10 h-10 border-4 border-[#0070f3] border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-slate-500 font-semibold text-sm">Loading homework assignments...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12 font-sans select-none">
      {/* Page Header */}
      <div className="flex justify-between items-center">
        <div>
          <span className="text-xs font-black text-slate-400 uppercase tracking-widest block mb-0.5">ADMIN</span>
          <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight">Homework</h1>
          <p className="text-slate-500 text-sm mt-1 font-semibold">Create and grade homework</p>
        </div>
        {isStaff && (
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center gap-2 px-6 py-3 bg-[#0070f3] hover:bg-[#0060df] text-white rounded-full font-bold text-sm shadow-md shadow-blue-500/10 active:scale-[0.98] transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Homework</span>
          </button>
        )}
      </div>

      {/* Table Section */}
      <div className="bg-white rounded-[32px] border border-slate-200/50 shadow-sm overflow-hidden flex flex-col animate-fadeIn">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100">
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs w-[30%]">Assignment</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Subject</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Batch</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Deadline</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Marks</th>
                {isStaff && <th className="px-8 py-5 w-[10%]"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {homeworkList.map((h) => (
                <tr key={h.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-8 py-5">
                    <div className="text-slate-800 font-semibold text-sm">{h.title}</div>
                    {h.description && (
                      <div className="text-slate-400 text-xs mt-1 font-medium max-w-md line-clamp-1">
                        {h.description}
                      </div>
                    )}
                  </td>
                  <td className="px-8 py-5 text-slate-600 font-semibold text-sm">{h.subject}</td>
                  <td className="px-8 py-5 text-slate-500 font-semibold text-sm">
                    <span className="bg-slate-100 px-3 py-1 rounded-full text-xs text-slate-700 font-bold">
                      {h.batchName || 'General'}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-slate-500 font-semibold text-sm">{h.deadline}</td>
                  <td className="px-8 py-5 text-slate-500 font-bold text-sm">
                    <span className="bg-blue-50 text-[#0070f3] px-2.5 py-1 rounded-md">
                      {h.marks} M
                    </span>
                  </td>
                  {isStaff && (
                    <td className="px-8 py-5 text-right">
                      <button
                        onClick={() => handleDelete(h.id!)}
                        className="text-slate-400 hover:text-red-500 p-2 rounded-lg hover:bg-red-50/50 transition-all cursor-pointer"
                        title="Delete Homework"
                      >
                        <Trash2 className="w-5 h-5" strokeWidth={1.5} />
                      </button>
                    </td>
                  )}
                </tr>
              ))}
              {homeworkList.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-8 py-12 text-center text-slate-400 font-medium text-sm">
                    No homework assignments created.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Homework Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-3xl shadow-xl w-full max-w-md overflow-hidden border border-slate-100 p-6 space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-950 text-lg flex items-center gap-2">
                <ClipboardList className="w-5 h-5 text-[#0070f3]" />
                Add Homework
              </h3>
              <button onClick={() => setShowAddForm(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Assignment Title</label>
                <input
                  required
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium placeholder-slate-400 text-sm"
                  placeholder="e.g. Projectile Motion Exercises"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Subject</label>
                  <input
                    required
                    type="text"
                    value={newSubject}
                    onChange={(e) => setNewSubject(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium placeholder-slate-400 text-sm"
                    placeholder="e.g. Physics"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Total Marks</label>
                  <input
                    required
                    type="number"
                    value={newMarks}
                    onChange={(e) => setNewMarks(Number(e.target.value))}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm"
                    placeholder="100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Batch</label>
                <select
                  required
                  value={newBatch}
                  onChange={(e) => setNewBatch(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm bg-white"
                >
                  {batches.map((b) => (
                    <option key={b.id} value={b.name || b.class}>
                      {b.name || b.class}
                    </option>
                  ))}
                  {batches.length === 0 && (
                    <>
                      <option value="JEE Advanced 2026">JEE Advanced 2026</option>
                      <option value="NEET 2026 Foundation">NEET 2026 Foundation</option>
                    </>
                  )}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Deadline</label>
                <input
                  required
                  type="date"
                  value={newDeadline}
                  onChange={(e) => setNewDeadline(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Description</label>
                <textarea
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  rows={3}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium placeholder-slate-400 text-sm resize-none"
                  placeholder="Enter details, reference books, problems to solve..."
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-5 py-2.5 text-slate-500 font-bold text-sm hover:bg-slate-50 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#0070f3] hover:bg-[#0060df] text-white font-bold text-sm rounded-xl shadow-md cursor-pointer"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
