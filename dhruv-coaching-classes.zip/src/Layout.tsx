import React, { useState, useEffect } from 'react';
import { Outlet, Link, useNavigate, useLocation } from 'react-router';
import { useAuth } from './AuthContext';
import { db } from './firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  ClipboardList,
  FileSpreadsheet,
  Wallet,
  BookOpen,
  LogOut,
  Menu,
  X,
  UserPlus,
  Video,
  Layers,
  FileQuestion,
  Bell,
  Award,
  User,
  Clock,
  Film,
  Megaphone,
  Moon,
  Search
} from 'lucide-react';

export default function Layout() {
  const { role, isEnrolled, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);

  useEffect(() => {
    if (role === 'admin') {
      const q = query(collection(db, 'enrollments'), where('status', '==', 'pending'));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        setPendingCount(snapshot.size);
      }, (error) => {
        console.error("Error listening to pending enrollments:", error);
      });
      return () => unsubscribe();
    }
  }, [role]);

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  // Nav items curated and ordered to match the Scholarly Screenshots for Admin,
  // while fallback items are kept elegant for teachers/students.
  const navItems = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard, roles: ['admin', 'teacher', 'student'] },
    { name: 'Students', path: '/students', icon: Users, roles: ['admin', 'teacher'] },
    { name: 'Batches', path: '/batches', icon: Layers, roles: ['admin', 'teacher'] },
    { name: 'Courses', path: '/courses', icon: GraduationCap, roles: ['admin', 'teacher'] },
    { name: 'Live Classes', path: '/live-classes', icon: Video, roles: ['admin', 'teacher'] },
    { name: 'Recorded Lectures', path: '/lectures', icon: Film, roles: ['admin', 'teacher'] },
    { name: 'Study Material', path: '/study-material', icon: BookOpen, roles: ['admin', 'teacher'] },
    { name: 'Homework', path: '/homework', icon: ClipboardList, roles: ['admin', 'teacher'] },
    { name: 'Tests', path: '/tests', icon: FileQuestion, roles: ['admin', 'teacher'] },
    { name: 'Notifications', path: '/notifications', icon: Bell, roles: ['admin', 'teacher', 'student'] },
    { name: 'Announcements', path: '/announcements', icon: Megaphone, roles: ['admin', 'teacher', 'student'] },
    
    // Fallbacks and extra links for non-admin/other features
    { name: 'Timetable', path: '/timetable', icon: Clock, roles: ['teacher', 'student'] },
    { name: 'Analytics', path: '/performance', icon: Award, roles: ['teacher', 'student'] },
    { name: 'My Profile', path: '/profile', icon: User, roles: ['student'] },
    { name: 'Enrollments', path: '/enrollments', icon: UserPlus, roles: ['admin'] },
    { name: 'Teachers Log', path: '/teachers', icon: GraduationCap, roles: ['admin'] },
    { name: 'Attendance Sheet', path: '/attendance', icon: ClipboardList, roles: ['teacher'] },
    { name: 'Marks Log', path: '/marks', icon: FileSpreadsheet, roles: ['teacher'] },
    { name: 'Fees Ledger', path: '/fees', icon: Wallet, roles: ['student'] },
  ];

  const filteredNav = navItems.filter(item => {
    if (!role || !item.roles.includes(role)) return false;
    if (role === 'student' && !isEnrolled && item.path !== '/dashboard') return false;
    return true;
  });

  return (
    <div className="flex min-h-screen w-full bg-[#f8fafc] text-[#1e293b] font-sans overflow-hidden select-none">
      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-white flex flex-col border-r border-slate-100
        md:relative md:translate-x-0 transition-transform duration-300 ease-in-out
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        {/* Brand Container */}
        <div className="p-6 pb-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 bg-slate-950 rounded-full flex items-center justify-center text-white">
              <GraduationCap className="w-6 h-6" strokeWidth={1.8} />
            </div>
            <div>
              <h1 className="text-base font-black text-slate-900 tracking-tight leading-none">Dhruv Coaching</h1>
              <span className="text-[11px] font-bold text-slate-500 block mt-1">Class Dongaon</span>
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mt-1">
                {role === 'admin' ? 'ADMIN PORTAL' : role === 'teacher' ? 'TEACHER PORTAL' : 'STUDENT PORTAL'}
              </span>
            </div>
          </div>
          <button className="md:hidden cursor-pointer" onClick={() => setSidebarOpen(false)}>
            <X className="w-5 h-5 text-slate-400 hover:text-slate-600" />
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 px-4 py-4 overflow-y-auto space-y-1 scrollbar-none">
          {filteredNav.map(item => {
            const Icon = item.icon;
            const isActive = location.pathname.startsWith(item.path);
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setSidebarOpen(false)}
                className={`
                  flex items-center justify-between px-4 py-3 rounded-2xl transition-all font-bold text-sm
                  ${isActive 
                    ? 'bg-[#0070f3] text-white shadow-lg shadow-blue-500/10' 
                    : 'text-slate-600 hover:text-[#0070f3] hover:bg-[#ebf2fe]/40'
                  }
                `}
              >
                <div className="flex items-center gap-3.5">
                  <Icon className="w-5 h-5" strokeWidth={isActive ? 2.2 : 1.8} />
                  <span>{item.name}</span>
                </div>
                {item.path === '/enrollments' && pendingCount > 0 && (
                  <span className="px-2 py-0.5 text-[10px] font-black bg-amber-500 text-white rounded-full">
                    {pendingCount}
                  </span>
                )}
              </Link>
            );
          })}
        </nav>

        {/* Logout Section */}
        <div className="p-4 border-t border-slate-100">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3.5 w-full px-4 py-3 rounded-2xl text-red-500 hover:bg-red-50/50 font-bold text-sm transition-all cursor-pointer"
          >
            <LogOut className="w-5 h-5" strokeWidth={2} />
            <span>Log out</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Top Header */}
        <header className="h-20 border-b border-slate-100 flex items-center justify-between px-10 shrink-0 bg-white">
          <div className="flex items-center gap-4 flex-1">
            <button 
              className="md:hidden p-2 -ml-2 text-slate-500 hover:text-slate-700 cursor-pointer"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="w-6 h-6" />
            </button>
            
            {/* Search Bar - Exactly matching screenshots */}
            <div className="relative w-72 hidden sm:block">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
              <input 
                type="text" 
                placeholder="Search everywhere..."
                className="w-full bg-[#f1f5f9] border border-transparent rounded-2xl pl-11 pr-4 py-2.5 text-sm font-semibold text-slate-800 placeholder-slate-400 outline-none h-11"
              />
            </div>
          </div>

          {/* Right Accessories */}
          <div className="flex items-center gap-6">
            {/* Theme / Moon Icon */}
            <button className="text-slate-400 hover:text-slate-600 cursor-pointer transition-colors" title="Toggle Theme">
              <Moon className="w-5 h-5" strokeWidth={2} />
            </button>

            {/* Profile Avatar with custom high-contrast photo */}
            <div className="flex items-center gap-3">
              <img 
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150" 
                alt="Profile" 
                className="w-10 h-10 rounded-full object-cover ring-2 ring-slate-100"
              />
            </div>
          </div>
        </header>
        
        {/* Content Wrapper */}
        <div className="flex-1 overflow-auto p-10 bg-[#f8fafc]">
          <div className="max-w-7xl mx-auto h-full flex flex-col">
            <Outlet />
          </div>
        </div>
      </main>
    </div>
  );
}
