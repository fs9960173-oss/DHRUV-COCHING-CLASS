import React, { useState, useEffect } from 'react';
import { collection, getDocs, addDoc, deleteDoc, doc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { useAuth } from './AuthContext';
import { Trash2, Plus, X, Video, ExternalLink } from 'lucide-react';

interface LiveClass {
  id?: string;
  title: string;
  subject: string;
  date: string;
  time: string;
  teacher: string;
  meetingLink?: string;
  batchName?: string;
}

const DEFAULT_LIVE_CLASSES = [
  { title: 'Human Physiology Basics', subject: 'Biology', date: '2026-07-19', time: '18:00', teacher: 'Prof. R. Sharma', meetingLink: 'https://meet.google.com/abc-defg-hij', batchName: 'NEET 2026 Foundation' },
  { title: 'Calculus Marathon', subject: 'Mathematics', date: '2026-07-18', time: '18:00', teacher: 'Prof. R. Sharma', meetingLink: 'https://meet.google.com/abc-defg-hij', batchName: 'JEE Advanced 2026' }
];

export default function LiveClasses() {
  const { role } = useAuth();
  const [classes, setClasses] = useState<LiveClass[]>([]);
  const [batches, setBatches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);

  // Form states
  const [newTitle, setNewTitle] = useState('');
  const [newMeetingLink, setNewMeetingLink] = useState('https://meet.google.com/abc-defg-hij');
  const [newDate, setNewDate] = useState('');
  const [newTime, setNewTime] = useState('18:00');
  const [newSubject, setNewSubject] = useState('Physics');
  const [newTeacher, setNewTeacher] = useState('Prof. R. Sharma');
  const [newBatch, setNewBatch] = useState('');

  const isStaff = role === 'admin' || role === 'teacher';

  const fetchLiveClasses = async () => {
    try {
      setLoading(true);
      const snap = await getDocs(collection(db, 'live_classes'));
      let fetched = snap.docs.map(d => ({ id: d.id, ...d.data() } as LiveClass));

      const bSnap = await getDocs(collection(db, 'batches'));
      const fetchedBatches = bSnap.docs.map(d => ({ id: d.id, ...d.data() }));
      setBatches(fetchedBatches);
      if (fetchedBatches.length > 0) {
        setNewBatch(fetchedBatches[0].name || fetchedBatches[0].class);
      } else {
        setNewBatch('JEE Advanced 2026');
      }

      if (fetched.length === 0) {
        // Auto-seed
        for (const item of DEFAULT_LIVE_CLASSES) {
          const docRef = await addDoc(collection(db, 'live_classes'), item);
          fetched.push({ id: docRef.id, ...item });
        }
      }

      setClasses(fetched);
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'live_classes');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLiveClasses();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDate || !newTime || !newTeacher.trim() || !newSubject.trim()) return;

    const newClass = {
      title: newTitle.trim(),
      meetingLink: newMeetingLink.trim(),
      date: newDate,
      time: newTime,
      subject: newSubject.trim(),
      teacher: newTeacher.trim(),
      batchName: newBatch
    };

    try {
      await addDoc(collection(db, 'live_classes'), newClass);
      setNewTitle('');
      setNewSubject('Physics');
      setNewMeetingLink('https://meet.google.com/abc-defg-hij');
      setShowAddForm(false);
      fetchLiveClasses();
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'live_classes');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this live class?')) return;
    try {
      await deleteDoc(doc(db, 'live_classes', id));
      fetchLiveClasses();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'live_classes');
    }
  };

  if (loading) {
    return (
      <div className="min-h-[400px] flex flex-col items-center justify-center font-sans">
        <div className="w-10 h-10 border-4 border-[#0070f3] border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-slate-500 font-semibold text-sm">Loading live classes...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12 font-sans select-none">
      {/* Page Header */}
      <div className="flex justify-between items-center">
        <div>
          <span className="text-xs font-black text-slate-400 uppercase tracking-widest block mb-0.5">ADMIN</span>
          <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight">Live Classes</h1>
          <p className="text-slate-500 text-sm mt-1 font-semibold">Schedule live sessions</p>
        </div>
        {isStaff && (
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center gap-2 px-6 py-3 bg-[#0070f3] hover:bg-[#0060df] text-white rounded-full font-bold text-sm shadow-md shadow-blue-500/10 active:scale-[0.98] transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Live Class</span>
          </button>
        )}
      </div>

      {/* Table Section */}
      <div className="bg-white rounded-[32px] border border-slate-200/50 shadow-sm overflow-hidden flex flex-col animate-fadeIn">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100">
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs w-[25%]">Title</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Subject</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Batch</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Schedule</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Teacher</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Meeting</th>
                {isStaff && <th className="px-8 py-5 w-[10%]"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {classes.map((c) => (
                <tr key={c.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-8 py-5 text-slate-800 font-semibold text-sm">{c.title}</td>
                  <td className="px-8 py-5 text-slate-600 font-semibold text-sm">{c.subject}</td>
                  <td className="px-8 py-5 text-slate-500 font-semibold text-sm">
                    <span className="bg-slate-100 px-3 py-1 rounded-full text-xs text-slate-700 font-bold">
                      {c.batchName || 'General'}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-slate-500 font-medium text-sm">
                    {c.date} ({c.time})
                  </td>
                  <td className="px-8 py-5 text-slate-500 font-medium text-sm">{c.teacher}</td>
                  <td className="px-8 py-5">
                    {c.meetingLink ? (
                      <a
                        href={c.meetingLink}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-1 text-[#0070f3] hover:underline font-bold text-xs"
                      >
                        Join Link <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    ) : (
                      <span className="text-slate-400 text-xs">-</span>
                    )}
                  </td>
                  {isStaff && (
                    <td className="px-8 py-5 text-right">
                      <button
                        onClick={() => handleDelete(c.id!)}
                        className="text-slate-400 hover:text-red-500 p-2 rounded-lg hover:bg-red-50/50 transition-all cursor-pointer"
                        title="Delete Live Class"
                      >
                        <Trash2 className="w-5 h-5" strokeWidth={1.5} />
                      </button>
                    </td>
                  )}
                </tr>
              ))}
              {classes.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-8 py-12 text-center text-slate-400 font-medium text-sm">
                    No live classes scheduled.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Live Class Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-3xl shadow-xl w-full max-w-md overflow-hidden border border-slate-100 p-6 space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-950 text-lg flex items-center gap-2">
                <Video className="w-5 h-5 text-[#0070f3]" />
                Add Live Class
              </h3>
              <button onClick={() => setShowAddForm(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Title</label>
                <input
                  required
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium placeholder-slate-400 text-sm"
                  placeholder="e.g. Kinematics L1"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Meeting Link</label>
                <input
                  required
                  type="url"
                  value={newMeetingLink}
                  onChange={(e) => setNewMeetingLink(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm"
                  placeholder="e.g. https://meet.google.com/..."
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Date</label>
                  <input
                    required
                    type="date"
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Time</label>
                  <input
                    required
                    type="time"
                    value={newTime}
                    onChange={(e) => setNewTime(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Subject</label>
                  <input
                    required
                    type="text"
                    value={newSubject}
                    onChange={(e) => setNewSubject(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm"
                    placeholder="e.g. Physics"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Teacher</label>
                  <input
                    required
                    type="text"
                    value={newTeacher}
                    onChange={(e) => setNewTeacher(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm"
                    placeholder="Prof. R. Sharma"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Batch</label>
                <select
                  required
                  value={newBatch}
                  onChange={(e) => setNewBatch(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm bg-white"
                >
                  {batches.map((b) => (
                    <option key={b.id} value={b.name || b.class}>
                      {b.name || b.class}
                    </option>
                  ))}
                  {batches.length === 0 && (
                    <>
                      <option value="JEE Advanced 2026">JEE Advanced 2026</option>
                      <option value="NEET 2026 Foundation">NEET 2026 Foundation</option>
                    </>
                  )}
                </select>
              </div>

              <div className="flex justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-5 py-2.5 text-slate-500 font-bold text-sm hover:bg-slate-50 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#0070f3] hover:bg-[#0060df] text-white font-bold text-sm rounded-xl shadow-md cursor-pointer"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
