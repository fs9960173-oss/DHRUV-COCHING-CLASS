import React, { useEffect, useState } from 'react';
import { signInWithPopup } from 'firebase/auth';
import { auth, googleProvider } from './firebase';
import { useNavigate } from 'react-router';
import { useAuth } from './AuthContext';
import { 
  GraduationCap, 
  Phone, 
  Mail,
  Lock,
  Eye,
  EyeOff,
  Sparkles
} from 'lucide-react';

export default function Login() {
  const navigate = useNavigate();
  const { user, loading, loginWithPhone, loginAsAdmin } = useAuth();
  
  // Tab states: 'admin' (labeled "Password") or 'student' (labeled "OTP")
  const [activeTab, setActiveTab] = useState<'admin' | 'student'>('student');
  
  // Selected demo pill state: 'student' | 'admin' | null
  const [selectedDemo, setSelectedDemo] = useState<'student' | 'admin' | null>(null);

  const [phoneNumber, setPhoneNumber] = useState('');
  const [phoneError, setPhoneError] = useState('');
  
  const [adminId, setAdminId] = useState('');
  const [adminPass, setAdminPass] = useState('');
  const [adminError, setAdminError] = useState('');
  const [adminSuccess, setAdminSuccess] = useState(false);
  
  const [showPassword, setShowPassword] = useState(false);
  const [forgotMsg, setForgotMsg] = useState(false);

  useEffect(() => {
    if (user) {
      navigate('/dashboard');
    }
  }, [user, navigate]);

  const handleGoogleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error('Google Sign In Error:', error);
    }
  };

  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPhoneError('');
    setForgotMsg(false);
    
    const cleanPhone = phoneNumber.replace(/\D/g, '');
    if (cleanPhone.length !== 10) {
      setPhoneError('Please enter a valid 10-digit phone number.');
      return;
    }
    
    try {
      await loginWithPhone(cleanPhone);
      navigate('/dashboard');
    } catch (err) {
      setPhoneError('Failed to log in with phone number. Please try again.');
    }
  };

  const handleAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminError('');
    setAdminSuccess(false);
    setForgotMsg(false);

    if (!adminId.trim()) {
      setAdminError('Please enter Email / Mobile / Student ID.');
      return;
    }
    if (!adminPass) {
      setAdminError('Please enter password.');
      return;
    }

    try {
      const isSuccess = await loginAsAdmin(adminId, adminPass);
      if (isSuccess) {
        setAdminSuccess(true);
        navigate('/dashboard');
      } else {
        setAdminError('Access Denied: Incorrect ID or password.');
      }
    } catch (err) {
      setAdminError('An error occurred during password login. Please try again.');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center font-sans">
        <div className="w-12 h-12 border-4 border-[#0070f3] border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-slate-600 font-medium font-sans">Verifying credentials...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white grid grid-cols-1 lg:grid-cols-12 font-sans selection:bg-[#0070f3] selection:text-white">
      {/* Left side: Premium Image Banner (only large screens) */}
      <div className="hidden lg:flex lg:col-span-5 bg-slate-950 text-white flex-col justify-between p-12 relative overflow-hidden">
        {/* Background Image */}
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-85"
          style={{ 
            backgroundImage: "url('https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=1200')" 
          }}
        />
        {/* Transparent Dark Blue Overlay */}
        <div className="absolute inset-0 bg-gradient-to-tr from-slate-950 via-slate-950/90 to-blue-950/60 mix-blend-multiply z-10" />

        {/* Brand logo */}
        <div className="flex items-center gap-3 z-20">
          <div className="w-10 h-10 bg-[#0070f3] rounded-full flex items-center justify-center shadow-md">
            <GraduationCap className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="font-display font-extrabold text-xl tracking-tight text-white leading-none">Scholarly</div>
            <div className="text-[9px] text-slate-400 font-bold tracking-widest uppercase mt-1">PREMIUM COACHING PORTAL</div>
          </div>
        </div>

        {/* Hero content */}
        <div className="space-y-6 max-w-md z-20 my-auto">
          <h1 className="text-5xl font-display font-extrabold tracking-tight leading-tight text-white">
            Learn <span className="text-[#ff941a]">smarter,</span><br />not harder.
          </h1>
          <p className="text-slate-300 text-sm leading-relaxed font-normal">
            A modern, distraction-free student portal — live classes, lectures, homework, tests, attendance and AI study coaching in one liquid-glass interface.
          </p>
          <div className="flex items-center gap-2 text-[#ffa133] font-medium text-sm">
            <Sparkles className="w-4 h-4 text-[#ffa133]" />
            <span>AI-powered study suggestions included</span>
          </div>
        </div>

        {/* Footer */}
        <div className="z-20 text-xs text-slate-400 font-medium">
          © 2026 Scholarly. All rights reserved.
        </div>
      </div>

      {/* Right side: Modern login form */}
      <div className="col-span-1 lg:col-span-7 flex flex-col justify-center px-6 sm:px-16 lg:px-24 py-12 bg-white relative">
        <div className="max-w-md w-full mx-auto">
          
          {/* Mobile Logo Header */}
          <div className="lg:hidden flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-[#0070f3] rounded-full flex items-center justify-center shadow-md">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="font-display font-extrabold text-xl tracking-tight text-slate-950">Scholarly</div>
              <div className="text-[9px] text-slate-500 font-bold tracking-widest uppercase">PREMIUM COACHING PORTAL</div>
            </div>
          </div>

          {/* Form Header */}
          <h2 className="text-4xl font-display font-extrabold text-slate-900 tracking-tight">Sign in</h2>
          <p className="text-slate-500 text-sm mt-2 font-medium">Use your email, mobile or student ID.</p>

          {/* Toggle pill container */}
          <div className="mt-8 bg-slate-100 p-1 rounded-2xl flex border border-slate-200/40">
            <button
              type="button"
              onClick={() => {
                setActiveTab('admin');
                setSelectedDemo(null);
                setPhoneError('');
                setAdminError('');
                setForgotMsg(false);
              }}
              className={`flex-1 py-2.5 text-center font-bold text-xs rounded-xl tracking-widest uppercase transition-all duration-250 ${
                activeTab === 'admin'
                  ? 'bg-white text-slate-900 shadow-sm border border-slate-200/45'
                  : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              Password
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('student');
                setSelectedDemo(null);
                setPhoneError('');
                setAdminError('');
                setForgotMsg(false);
              }}
              className={`flex-1 py-2.5 text-center font-bold text-xs rounded-xl tracking-widest uppercase transition-all duration-250 ${
                activeTab === 'student'
                  ? 'bg-white text-slate-900 shadow-sm border border-slate-200/45'
                  : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              OTP
            </button>
          </div>

          {/* Tab Contents */}
          <div className="mt-8">
            {activeTab === 'admin' ? (
              /* Admin & Student Password Form */
              <form onSubmit={handleAdminSubmit} className="space-y-5">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1.5">
                    Email / Mobile / Student ID
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                    <input
                      type="text"
                      required
                      value={adminId}
                      onChange={(e) => {
                        setAdminId(e.target.value);
                        setSelectedDemo(null);
                      }}
                      placeholder="admin@portal.com"
                      className="w-full pl-11 pr-4 py-3 bg-[#ebf2fe]/20 border border-slate-200/80 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/20 focus:bg-white outline-none text-slate-900 font-medium placeholder-slate-400 transition-all text-sm"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1.5">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      value={adminPass}
                      onChange={(e) => {
                        setAdminPass(e.target.value);
                        setSelectedDemo(null);
                      }}
                      placeholder="••••••••"
                      className="w-full pl-11 pr-11 py-3 bg-[#ebf2fe]/20 border border-slate-200/80 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/20 focus:bg-white outline-none text-slate-900 font-medium placeholder-slate-400 transition-all text-sm"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 focus:outline-none"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {adminError && (
                  <div className="bg-red-50 border border-red-100 p-3.5 rounded-xl text-red-800 text-xs font-medium space-y-0.5 animate-fadeIn">
                    <p className="font-bold flex items-center gap-1 text-red-950">
                      ⚠️ Access Denied
                    </p>
                    <p>{adminError}</p>
                  </div>
                )}

                {adminSuccess && (
                  <div className="bg-emerald-50 border border-emerald-100 p-3.5 rounded-xl text-emerald-800 text-xs font-medium animate-fadeIn">
                    ✓ Credentials Verified. Logging in...
                  </div>
                )}

                {/* Submit Row */}
                <div className="flex items-center justify-between text-xs sm:text-sm pt-1">
                  <label className="flex items-center gap-2 cursor-pointer text-slate-600 font-medium select-none">
                    <input 
                      type="checkbox" 
                      defaultChecked 
                      className="w-4 h-4 rounded border-slate-300 text-[#0070f3] focus:ring-[#0070f3] accent-[#0070f3]" 
                    />
                    <span>Remember me</span>
                  </label>
                  <button 
                    type="button"
                    onClick={() => setForgotMsg(!forgotMsg)}
                    className="text-[#0070f3] hover:text-[#0060df] font-semibold transition-colors"
                  >
                    Forgot password?
                  </button>
                </div>

                {forgotMsg && (
                  <div className="text-xs text-blue-800 bg-blue-50 p-3.5 rounded-xl border border-blue-100 leading-relaxed font-medium animate-fadeIn">
                    Please contact the coaching classes administrator to reset your registered password credentials.
                  </div>
                )}

                <button
                  type="submit"
                  disabled={adminSuccess}
                  className="w-full mt-2 flex items-center justify-center gap-2 bg-[#0070f3] hover:bg-[#0060df] text-white font-bold py-3.5 px-6 rounded-xl shadow-lg shadow-blue-500/20 active:scale-[0.98] transition-all cursor-pointer text-sm"
                >
                  <span>Sign in</span>
                </button>
              </form>
            ) : (
              /* Student OTP Form */
              <form onSubmit={handlePhoneSubmit} className="space-y-5">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1.5">
                    Enter Mobile Number
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                    <input
                      type="text"
                      maxLength={10}
                      required
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                      placeholder="98765 43210"
                      className="w-full pl-11 pr-4 py-3 bg-[#ebf2fe]/20 border border-slate-200/80 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/20 focus:bg-white outline-none text-slate-900 font-medium placeholder-slate-400 transition-all text-sm"
                    />
                  </div>
                  {phoneError && (
                    <p className="text-xs font-semibold text-red-600 mt-1.5 flex items-center gap-1">
                      ⚠️ {phoneError}
                    </p>
                  )}
                </div>

                <div className="flex items-center justify-between text-xs sm:text-sm pt-1">
                  <label className="flex items-center gap-2 cursor-pointer text-slate-600 font-medium select-none">
                    <input 
                      type="checkbox" 
                      defaultChecked 
                      className="w-4 h-4 rounded border-slate-300 text-[#0070f3] focus:ring-[#0070f3] accent-[#0070f3]" 
                    />
                    <span>Remember me</span>
                  </label>
                  <button 
                    type="button"
                    onClick={() => setForgotMsg(!forgotMsg)}
                    className="text-[#0070f3] hover:text-[#0060df] font-semibold transition-colors"
                  >
                    Forgot password?
                  </button>
                </div>

                {forgotMsg && (
                  <div className="text-xs text-blue-800 bg-blue-50 p-3.5 rounded-xl border border-blue-100 leading-relaxed font-medium animate-fadeIn">
                    Please use your registered mobile number. For help resetting your student profile, contact your center head.
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full mt-2 flex items-center justify-center gap-2 bg-[#0070f3] hover:bg-[#0060df] text-white font-bold py-3.5 px-6 rounded-xl shadow-lg shadow-blue-500/20 active:scale-[0.98] transition-all cursor-pointer text-sm"
                >
                  <span>Sign in</span>
                </button>

                <div className="flex items-center my-4">
                  <div className="flex-1 border-t border-slate-100"></div>
                  <span className="px-3 text-slate-400 text-[10px] font-bold uppercase tracking-wider select-none">or sign in with</span>
                  <div className="flex-1 border-t border-slate-100"></div>
                </div>

                <button
                  type="button"
                  onClick={handleGoogleLogin}
                  className="w-full flex items-center justify-center gap-2.5 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 font-bold py-3.5 px-6 rounded-xl shadow-sm hover:shadow transition-all cursor-pointer text-sm"
                >
                  <img 
                    className="h-5 w-5 bg-white rounded p-0.5 select-none" 
                    src="https://www.svgrepo.com/show/475656/google-color.svg" 
                    alt="Google" 
                  />
                  <span>Sign in with Google</span>
                </button>
              </form>
            )}
          </div>

          {/* Demo Credentials Section matching the screenshots exactly */}
          <div className="mt-10 bg-slate-50 border border-slate-200/60 rounded-2xl p-6 text-center shadow-sm">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3 select-none">
              DEMO CREDENTIALS
            </div>
            <div className="flex gap-3 justify-center">
              <button
                type="button"
                onClick={() => {
                  setActiveTab('admin');
                  setSelectedDemo('student');
                  setAdminId('rahul@portal.com');
                  setAdminPass('student123');
                  setShowPassword(true);
                  setPhoneError('');
                  setAdminError('');
                  setForgotMsg(false);
                }}
                className={`flex-1 py-2.5 px-4 rounded-full text-xs font-bold shadow-sm transition-all duration-200 cursor-pointer ${
                  selectedDemo === 'student'
                    ? 'bg-[#ff8800] text-white border border-[#ff8800] hover:bg-[#e07700]'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                Student
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('admin');
                  setSelectedDemo('admin');
                  setAdminId('admin@portal.com');
                  setAdminPass('admin123');
                  setShowPassword(true);
                  setPhoneError('');
                  setAdminError('');
                  setForgotMsg(false);
                }}
                className={`flex-1 py-2.5 px-4 rounded-full text-xs font-bold shadow-sm transition-all duration-200 cursor-pointer ${
                  selectedDemo === 'admin'
                    ? 'bg-[#ff8800] text-white border border-[#ff8800] hover:bg-[#e07700]'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                Admin
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
