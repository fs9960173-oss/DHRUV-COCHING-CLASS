import React, { useEffect, useState } from 'react';
import { collection, getDocs, addDoc, query, where } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { Student, Mark } from './types';
import { useAuth } from './AuthContext';
import { Plus, X } from 'lucide-react';

export default function Marks() {
  const { role, user } = useAuth();
  const [students, setStudents] = useState<Student[]>([]);
  const [marks, setMarks] = useState<Mark[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);

  useEffect(() => {
    async function fetchData() {
      setLoading(true);
      try {
        if (role === 'student') {
          const sq = query(collection(db, 'students'), where('userId', '==', user?.uid || ''));
          const studentSnap = await getDocs(sq);
          if (!studentSnap.empty) {
            const studentId = studentSnap.docs[0].id;
            const mq = query(collection(db, 'marks'), where('studentId', '==', studentId));
            const marksSnap = await getDocs(mq);
            setMarks(marksSnap.docs.map(d => ({ id: d.id, ... (d.data() as any) } as Mark)));
          }
        } else {
          const studentSnap = await getDocs(collection(db, 'students'));
          setStudents(studentSnap.docs.map(d => ({ id: d.id, ... (d.data() as any) } as Student)));

          const marksSnap = await getDocs(collection(db, 'marks'));
          setMarks(marksSnap.docs.map(d => ({ id: d.id, ... (d.data() as any) } as Mark)));
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'marks/students');
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, [role, user]);

  const handleAdd = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const newMark = {
      studentId: fd.get('studentId') as string,
      examName: fd.get('examName') as string,
      subject: fd.get('subject') as string,
      marksObtained: Number(fd.get('marksObtained')),
      totalMarks: Number(fd.get('totalMarks')),
      date: new Date().toISOString(),
    };

    try {
      const docRef = await addDoc(collection(db, 'marks'), newMark);
      setShowAddModal(false);
      setMarks(prev => [...prev, { id: docRef.id, ...newMark }]);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'marks');
    }
  };

  if (role === 'student') {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold text-slate-900">My Exam Marks</h1>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-sm font-medium text-slate-500 uppercase">
                <th className="px-6 py-4">Exam Name</th>
                <th className="px-6 py-4">Subject</th>
                <th className="px-6 py-4">Marks Obtained</th>
                <th className="px-6 py-4">Percentage</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {marks.length === 0 ? (
                <tr><td colSpan={4} className="px-6 py-8 text-center text-slate-500">No marks recorded.</td></tr>
              ) : (
                marks.map(m => (
                  <tr key={m.id}>
                    <td className="px-6 py-4 text-slate-900 font-medium">{m.examName}</td>
                    <td className="px-6 py-4 text-slate-600">{m.subject}</td>
                    <td className="px-6 py-4 font-bold text-slate-900">{m.marksObtained} / {m.totalMarks}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex px-2 py-1 rounded text-xs font-bold ${((m.marksObtained/m.totalMarks)*100) >= 35 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                        {((m.marksObtained / m.totalMarks) * 100).toFixed(1)}%
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
        <h1 className="text-2xl font-bold text-slate-900">Student Marks</h1>
        <button 
          onClick={() => setShowAddModal(true)}
          className="flex items-center justify-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add Marks
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-500">Loading...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 font-medium uppercase text-xs sticky top-0">
                <tr className="border-b border-slate-200">
                  <th className="px-4 py-3">Student</th>
                  <th className="px-4 py-3">Exam Name</th>
                  <th className="px-4 py-3">Subject</th>
                  <th className="px-4 py-3">Score</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {marks.length === 0 ? (
                  <tr><td colSpan={4} className="px-4 py-8 text-center text-slate-500">No marks recorded.</td></tr>
                ) : (
                  marks.map(m => {
                    const s = students.find(s => s.id === m.studentId);
                    return (
                      <tr key={m.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-4 py-3 font-medium text-slate-900">{s?.name || 'Unknown'}</td>
                        <td className="px-4 py-3 text-slate-600">{m.examName}</td>
                        <td className="px-4 py-3 text-slate-600">{m.subject}</td>
                        <td className="px-4 py-3 font-bold text-slate-900">
                          {m.marksObtained} / {m.totalMarks}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
              <h3 className="font-bold text-lg text-slate-900">Add Exam Marks</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAdd} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Student</label>
                <select required name="studentId" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none">
                  <option value="">Select Student</option>
                  {students.map(s => <option key={s.id} value={s.id}>{s.name} ({s.class})</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Exam Name</label>
                <input required name="examName" type="text" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="Mid Term" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Subject</label>
                <input required name="subject" type="text" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="Science" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Obtained</label>
                  <input required name="marksObtained" type="number" min="0" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="85" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Total</label>
                  <input required name="totalMarks" type="number" min="1" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="100" />
                </div>
              </div>
              <div className="pt-4 flex justify-end gap-3">
                <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 text-slate-600 font-medium hover:bg-slate-50 rounded-lg">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700">Save Marks</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
