import React, { useState, useEffect } from 'react';
import { collection, getDocs, addDoc, deleteDoc, doc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { useAuth } from './AuthContext';
import { Trash2, Plus, X, Bell, Calendar } from 'lucide-react';

interface NotificationItem {
  id?: string;
  title: string;
  category: string;
  batchName?: string;
  description?: string;
  sent: string;
}

const DEFAULT_NOTIFICATIONS = [
  { title: 'New Homework Uploaded', category: 'homework', batchName: 'All Batches', description: 'Please check the homework tab for the newly uploaded assignments.', sent: '15/07/2026, 10:17:37' },
  { title: 'Live Class Scheduled', category: 'live_class', batchName: 'JEE Advanced 2026', description: 'Physics live class is scheduled for tomorrow at 6:00 PM.', sent: '15/07/2026, 10:17:37' }
];

export default function Notifications() {
  const { role } = useAuth();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [batches, setBatches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);

  // Form states
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState('general');
  const [newBatch, setNewBatch] = useState('All Batches');
  const [newDescription, setNewDescription] = useState('');

  const isStaff = role === 'admin' || role === 'teacher';

  const fetchNotifications = async () => {
    try {
      setLoading(true);
      const snap = await getDocs(collection(db, 'notifications_simple'));
      let fetched = snap.docs.map(d => ({ id: d.id, ...d.data() } as NotificationItem));

      const bSnap = await getDocs(collection(db, 'batches'));
      const fetchedBatches = bSnap.docs.map(d => ({ id: d.id, ...d.data() }));
      setBatches(fetchedBatches);

      if (fetched.length === 0) {
        // Auto-seed
        for (const item of DEFAULT_NOTIFICATIONS) {
          const docRef = await addDoc(collection(db, 'notifications_simple'), item);
          fetched.push({ id: docRef.id, ...item });
        }
      }

      setNotifications(fetched);
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'notifications_simple');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDescription.trim()) return;

    // Format current date: 15/07/2026, 10:17:37
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    const formattedDate = `${pad(now.getDate())}/${pad(now.getMonth() + 1)}/${now.getFullYear()}, ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;

    const newNotif = {
      title: newTitle.trim(),
      category: newCategory,
      batchName: newBatch,
      description: newDescription.trim(),
      sent: formattedDate
    };

    try {
      await addDoc(collection(db, 'notifications_simple'), newNotif);
      setNewTitle('');
      setNewDescription('');
      setNewCategory('general');
      setNewBatch('All Batches');
      setShowAddForm(false);
      fetchNotifications();
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'notifications_simple');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this notification?')) return;
    try {
      await deleteDoc(doc(db, 'notifications_simple', id));
      fetchNotifications();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'notifications_simple');
    }
  };

  const getCategoryBadgeClass = (cat: string) => {
    switch (cat) {
      case 'homework': return 'bg-yellow-50 text-yellow-700 border border-yellow-100';
      case 'live_class': return 'bg-purple-50 text-purple-700 border border-purple-100';
      case 'exam': return 'bg-red-50 text-red-700 border border-red-100';
      case 'holiday': return 'bg-green-50 text-green-700 border border-green-100';
      case 'fee': return 'bg-indigo-50 text-indigo-700 border border-indigo-100';
      default: return 'bg-slate-50 text-slate-700 border border-slate-100';
    }
  };

  if (loading) {
    return (
      <div className="min-h-[400px] flex flex-col items-center justify-center font-sans">
        <div className="w-10 h-10 border-4 border-[#0070f3] border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-slate-500 font-semibold text-sm">Loading notifications...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12 font-sans select-none">
      {/* Page Header */}
      <div className="flex justify-between items-center">
        <div>
          <span className="text-xs font-black text-slate-400 uppercase tracking-widest block mb-0.5">ADMIN</span>
          <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight">Notifications</h1>
          <p className="text-slate-500 text-sm mt-1 font-semibold">Send alerts and system notifications</p>
        </div>
        {isStaff && (
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center gap-2 px-6 py-3 bg-[#0070f3] hover:bg-[#0060df] text-white rounded-full font-bold text-sm shadow-md shadow-blue-500/10 active:scale-[0.98] transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Notification</span>
          </button>
        )}
      </div>

      {/* Table Section */}
      <div className="bg-white rounded-[32px] border border-slate-200/50 shadow-sm overflow-hidden flex flex-col animate-fadeIn">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100">
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs w-[35%]">Notification</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Category</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Target Batch</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Sent At</th>
                {isStaff && <th className="px-8 py-5 w-[10%]"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {notifications.map((n) => (
                <tr key={n.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-8 py-5">
                    <div className="text-slate-800 font-semibold text-sm flex items-center gap-2">
                      <span className="p-1.5 bg-blue-50 text-[#0070f3] rounded-lg">
                        <Bell className="w-3.5 h-3.5" />
                      </span>
                      {n.title}
                    </div>
                    {n.description && (
                      <div className="text-slate-400 text-xs mt-1.5 font-medium max-w-md line-clamp-1">
                        {n.description}
                      </div>
                    )}
                  </td>
                  <td className="px-8 py-5">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${getCategoryBadgeClass(n.category)}`}>
                      {n.category.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-slate-500 font-semibold text-sm">
                    <span className="bg-slate-100 px-3 py-1 rounded-full text-xs text-slate-700 font-bold">
                      {n.batchName || 'All Batches'}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-slate-500 font-medium text-sm">
                    {n.sent}
                  </td>
                  {isStaff && (
                    <td className="px-8 py-5 text-right">
                      <button
                        onClick={() => handleDelete(n.id!)}
                        className="text-slate-400 hover:text-red-500 p-2 rounded-lg hover:bg-red-50/50 transition-all cursor-pointer"
                        title="Delete Notification"
                      >
                        <Trash2 className="w-5 h-5" strokeWidth={1.5} />
                      </button>
                    </td>
                  )}
                </tr>
              ))}
              {notifications.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-8 py-12 text-center text-slate-400 font-medium text-sm">
                    No notifications sent.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Notification Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-3xl shadow-xl w-full max-w-md overflow-hidden border border-slate-100 p-6 space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-950 text-lg flex items-center gap-2">
                <Bell className="w-5 h-5 text-[#0070f3]" />
                Add Notification
              </h3>
              <button onClick={() => setShowAddForm(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Notification Title</label>
                <input
                  required
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium placeholder-slate-400 text-sm"
                  placeholder="e.g. New Homework Uploaded"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm bg-white"
                  >
                    <option value="general">General</option>
                    <option value="live_class">Live Class</option>
                    <option value="homework">Homework</option>
                    <option value="exam">Exam</option>
                    <option value="holiday">Holiday</option>
                    <option value="fee">Fee</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Batch</label>
                  <select
                    value={newBatch}
                    onChange={(e) => setNewBatch(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm bg-white"
                  >
                    <option value="All Batches">All Batches</option>
                    {batches.map((b) => (
                      <option key={b.id} value={b.name || b.class}>
                        {b.name || b.class}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Description</label>
                <textarea
                  required
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  rows={4}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium placeholder-slate-400 text-sm resize-none"
                  placeholder="Enter detailed alert description..."
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-5 py-2.5 text-slate-500 font-bold text-sm hover:bg-slate-50 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#0070f3] hover:bg-[#0060df] text-white font-bold text-sm rounded-xl shadow-md cursor-pointer"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
