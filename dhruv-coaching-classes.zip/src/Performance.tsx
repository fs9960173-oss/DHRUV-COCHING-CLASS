import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, where } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { useAuth } from './AuthContext';
import { Student, Mark, Attendance, HomeworkSubmission } from './types';
import { Award, CheckCircle, TrendingUp, Sparkles, BrainCircuit, CheckSquare, RefreshCw, Calendar } from 'lucide-react';

export default function Performance() {
  const { role, user } = useAuth();
  const [studentInfo, setStudentInfo] = useState<Student | null>(null);
  const [marks, setMarks] = useState<Mark[]>([]);
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [submissions, setSubmissions] = useState<HomeworkSubmission[]>([]);
  const [loading, setLoading] = useState(true);

  const isStaff = role === 'admin' || role === 'teacher';

  const fetchData = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const studSnap = await getDocs(collection(db, 'students'));
      const studentProfiles = studSnap.docs.map(d => ({ id: d.id, ...d.data() } as Student));
      
      let targetStudentId = '';
      if (!isStaff) {
        const myProfile = studentProfiles.find(s => s.userId === user.uid);
        if (myProfile) {
          setStudentInfo(myProfile);
          targetStudentId = myProfile.id!;
        }
      } else {
        // If staff/admin, analyze first student in system for analysis/dashboard demo
        if (studentProfiles.length > 0) {
          setStudentInfo(studentProfiles[0]);
          targetStudentId = studentProfiles[0].id!;
        }
      }

      if (targetStudentId) {
        // Fetch matching metrics
        const mSnap = await getDocs(collection(db, 'marks'));
        const allMarks = mSnap.docs.map(d => d.data() as Mark);
        setMarks(allMarks.filter(m => m.studentId === targetStudentId));

        const attSnap = await getDocs(collection(db, 'attendance'));
        const allAtt = attSnap.docs.map(d => d.data() as Attendance);
        setAttendance(allAtt.filter(a => a.studentId === targetStudentId));

        const sSnap = await getDocs(collection(db, 'homework_submissions'));
        const allSubs = sSnap.docs.map(d => d.data() as HomeworkSubmission);
        setSubmissions(allSubs.filter(s => s.studentId === user.uid));
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, 'student/performance');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [role, user]);

  // Compute stats
  const totalClasses = attendance.length;
  const presentClasses = attendance.filter(a => a.status === 'present' || a.status === 'late').length;
  const attendanceRate = totalClasses > 0 ? Math.round((presentClasses / totalClasses) * 100) : 85; // Default mock rate if none logged

  const avgMarksPercentage = marks.length > 0 
    ? Math.round((marks.reduce((acc, m) => acc + (m.marksObtained / m.totalMarks), 0) / marks.length) * 100) 
    : 78; // Default mock marks if none logged

  const homeworkCompleted = submissions.filter(s => s.status === 'graded').length;
  const totalHomeworks = submissions.length || 5;
  const homeworkCompRate = totalHomeworks > 0 ? Math.round((homeworkCompleted / totalHomeworks) * 100) : 80;

  // AI suggestions list based on computed parameters
  const getAISuggestions = () => {
    const suggestions = [];
    if (attendanceRate < 90) {
      suggestions.push({
        title: 'Improve Lecture Attendance Rate',
        desc: `Your attendance is currently ${attendanceRate}%. Consistent virtual classroom presence helps catch fundamental physics & math chapters.`,
        urgency: 'high'
      });
    } else {
      suggestions.push({
        title: 'Excellent Lecture Attendance',
        desc: 'Keep up the 90%+ daily presence rate! Consistent attendance correlates strongly with success in upcoming term tests.',
        urgency: 'low'
      });
    }

    if (avgMarksPercentage < 80) {
      suggestions.push({
        title: 'Reinforce Subject Revision Notes',
        desc: 'Your average evaluation scores are at 78%. We suggest downloading handwritten notes and reviewing Recorded video segments weekly.',
        urgency: 'medium'
      });
    } else {
      suggestions.push({
        title: 'Outstanding Concept Mastery',
        desc: 'You are scoring in the elite tier (80%+). Try attempting advanced MCQ practice papers in physics and mathematics.',
        urgency: 'low'
      });
    }

    if (homeworkCompRate < 85) {
      suggestions.push({
        title: 'Ensure Timely Homework Uploads',
        desc: 'Keep tracking homework schedules. Completing assignments on time earns valuable teacher review remarks and consolidates topics.',
        urgency: 'medium'
      });
    }

    return suggestions;
  };

  if (loading) {
    return <div className="p-8 text-center text-slate-500 animate-pulse">Loading academic analytics profile...</div>;
  }

  if (!studentInfo) {
    return (
      <div className="p-12 text-center bg-white rounded-3xl border border-slate-200">
        <Sparkles className="w-12 h-12 text-slate-300 mx-auto mb-3" />
        <h3 className="text-lg font-bold text-slate-900">Performance Board Locked</h3>
        <p className="text-slate-500 text-sm">Please register your student enrollment profile to access comprehensive academic tracking charts.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12">
      {/* Upper overview header */}
      <div className="bg-gradient-to-tr from-slate-900 via-indigo-950 to-indigo-900 p-8 rounded-3xl text-white relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-xl">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(99,102,241,0.15),transparent)] animate-pulse" />
        <div className="space-y-2 relative z-10">
          <span className="bg-indigo-500/20 border border-indigo-400/30 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider text-indigo-300 flex items-center gap-1.5 w-fit">
            <BrainCircuit className="w-3.5 h-3.5" /> Dhruv AI Analyst
          </span>
          <h1 className="text-3xl font-extrabold tracking-tight">Academic Analytics</h1>
          <p className="text-slate-300 text-sm max-w-xl">
            {isStaff ? `Reviewing compiled performance cards for student: ${studentInfo.name}` : `Welcome back ${studentInfo.name}! Check your consolidated attendance grades, syllabus reports, and customized study plans.`}
          </p>
        </div>
        <button onClick={fetchData} className="p-3 bg-white/10 hover:bg-white/20 text-white rounded-2xl border border-white/10 flex items-center gap-2 text-xs font-bold relative z-10 transition-colors">
          <RefreshCw className="w-4 h-4" /> Sync Stats
        </button>
      </div>

      {/* Bento grid metrics overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Metric 1: Average Exam Score */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 flex items-center justify-between shadow-sm relative overflow-hidden group hover:border-slate-300 transition-all">
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Average Exam Score</span>
            <span className="text-4xl font-black text-slate-900 block">{avgMarksPercentage}%</span>
            <span className="text-xs text-emerald-600 font-extrabold flex items-center gap-1">
              <TrendingUp className="w-3.5 h-3.5" /> High progress tier
            </span>
          </div>
          <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center shrink-0 border border-indigo-100 shadow-sm group-hover:scale-105 transition-transform">
            <Award className="w-7 h-7" />
          </div>
        </div>

        {/* Metric 2: Attendance Percentage */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 flex items-center justify-between shadow-sm relative overflow-hidden group hover:border-slate-300 transition-all">
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Class Attendance</span>
            <span className="text-4xl font-black text-slate-900 block">{attendanceRate}%</span>
            <span className="text-xs text-indigo-600 font-extrabold flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" /> {presentClasses} sessions present
            </span>
          </div>
          {/* Custom circular SVG progress indicator */}
          <div className="relative w-14 h-14 shrink-0">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="28" cy="28" r="24" stroke="#EEF2F6" strokeWidth="4" fill="transparent" />
              <circle cx="28" cy="28" r="24" stroke="#6366F1" strokeWidth="4" fill="transparent" 
                strokeDasharray="150" strokeDashoffset={150 - (150 * attendanceRate) / 100} />
            </svg>
            <span className="absolute inset-0 flex items-center justify-center text-[10px] font-black text-indigo-600">
              {attendanceRate}%
            </span>
          </div>
        </div>

        {/* Metric 3: Homework completion rate */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 flex items-center justify-between shadow-sm relative overflow-hidden group hover:border-slate-300 transition-all">
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Homework Submissions</span>
            <span className="text-4xl font-black text-slate-900 block">{homeworkCompRate}%</span>
            <span className="text-xs text-emerald-600 font-extrabold flex items-center gap-1">
              <CheckCircle className="w-3.5 h-3.5" /> High completion rate
            </span>
          </div>
          <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center shrink-0 border border-emerald-100 shadow-sm group-hover:scale-105 transition-transform">
            <CheckSquare className="w-7 h-7" />
          </div>
        </div>

      </div>

      {/* Main Analysis Body: Custom SVG performance graph & AI suggestions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Marks Progress Chart (Custom visual SVG graph for reliable rendering without Recharts dependency) */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-extrabold text-slate-900 text-lg">Test Evaluation Progress</h3>
              <p className="text-slate-400 text-xs">A chronological log of your recent subject assessments.</p>
            </div>
            <span className="text-xs font-extrabold text-indigo-600 uppercase bg-indigo-50 px-2.5 py-1 rounded-lg">
              Physics & Math
            </span>
          </div>

          <div className="h-64 border-b border-l border-slate-200 relative pt-8 px-4 flex items-end justify-between gap-3">
            {marks.length === 0 ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400">
                <BrainCircuit className="w-10 h-10 text-slate-300 mb-2" />
                <p className="text-sm font-bold">No evaluation logs recorded yet</p>
                <p className="text-xs text-slate-400 mt-0.5">Attempt active tests to view progress curves here.</p>
              </div>
            ) : (
              marks.map((mark, idx) => {
                const percentage = Math.round((mark.marksObtained / mark.totalMarks) * 100);
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-2 group relative">
                    {/* Tooltip */}
                    <div className="absolute -top-10 opacity-0 group-hover:opacity-100 bg-slate-950 text-white text-[10px] font-black px-2 py-1 rounded shadow-lg transition-opacity z-10 whitespace-nowrap">
                      {mark.marksObtained}/{mark.totalMarks} Marks ({percentage}%)
                    </div>
                    {/* Visual Bar with gradient */}
                    <div 
                      style={{ height: `${percentage * 1.5}px` }} 
                      className="w-full max-w-[40px] bg-gradient-to-t from-indigo-500 via-indigo-600 to-rose-500 rounded-t-xl group-hover:scale-105 transition-all shadow-md"
                    />
                    {/* Subject label */}
                    <span className="text-[10px] font-bold text-slate-600 truncate max-w-[60px]">
                      {mark.examName}
                    </span>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* AI Recommendations */}
        <div className="lg:col-span-5 bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <h3 className="font-extrabold text-slate-900 text-lg flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-indigo-600 animate-pulse" />
            AI Study Suggestions
          </h3>
          <p className="text-slate-400 text-xs">Consolidated advisory insights designed to improve student grades.</p>

          <div className="space-y-3.5">
            {getAISuggestions().map((sug, idx) => (
              <div key={idx} className={`p-4 rounded-2xl border flex items-start gap-3.5 transition-all hover:shadow-md ${
                sug.urgency === 'high' 
                  ? 'bg-red-50/50 border-red-100' 
                  : sug.urgency === 'medium'
                    ? 'bg-amber-50/50 border-amber-100'
                    : 'bg-emerald-50/50 border-emerald-100'
              }`}>
                <div className={`p-1.5 rounded-xl shrink-0 ${
                  sug.urgency === 'high' 
                    ? 'bg-red-100 text-red-600' 
                    : sug.urgency === 'medium'
                      ? 'bg-amber-100 text-amber-600'
                      : 'bg-emerald-100 text-emerald-600'
                }`}>
                  <BrainCircuit className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-900 text-sm">{sug.title}</h4>
                  <p className="text-slate-600 text-xs mt-1 leading-relaxed">{sug.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}
