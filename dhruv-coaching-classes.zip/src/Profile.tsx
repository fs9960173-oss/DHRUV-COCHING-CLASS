import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, updateDoc, doc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { useAuth } from './AuthContext';
import { Student } from './types';
import { User, Shield, CreditCard, Mail, Phone, MapPin, School, Calendar, ArrowRight, Download, UploadCloud } from 'lucide-react';

export default function Profile() {
  const { user } = useAuth();
  const [student, setStudent] = useState<Student | null>(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);

  const fetchData = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const sSnap = await getDocs(collection(db, 'students'));
      const studentProfile = sSnap.docs.map(d => ({ id: d.id, ...d.data() } as Student)).find(s => s.userId === user.uid);
      if (studentProfile) {
        setStudent(studentProfile);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, 'student/profile');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [user]);

  const handleUpdate = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!student || !student.id) return;
    const fd = new FormData(e.currentTarget);
    const updated = {
      name: fd.get('name') as string,
      phone: fd.get('phone') as string,
      email: fd.get('email') as string,
      schoolName: fd.get('schoolName') as string,
      address: fd.get('address') as string,
    };

    try {
      await updateDoc(doc(db, 'students', student.id), updated);
      setEditing(false);
      fetchData();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'students/profile');
    }
  };

  const downloadIDCard = () => {
    alert('Generating premium Student ID Card PDF... Download initiated successfully!');
  };

  if (loading) {
    return <div className="p-8 text-center text-slate-500">Loading profile configuration...</div>;
  }

  if (!student) {
    return (
      <div className="p-12 text-center bg-white rounded-3xl border border-slate-200">
        <User className="w-12 h-12 text-slate-300 mx-auto mb-3" />
        <h3 className="text-lg font-bold text-slate-900">No Student Profile Linked</h3>
        <p className="text-slate-500 text-sm">Please submit your active student enrollment application to activate your Digital ID card.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-12">
      
      {/* Grid Layout splits Profile settings & Digital ID Card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Side: Profile Form settings */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6">
          <div className="flex justify-between items-center border-b border-slate-100 pb-4">
            <div>
              <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">Profile & Contact Details</h2>
              <p className="text-slate-400 text-xs">Verify class alignment or edit physical addresses and phone records.</p>
            </div>
            <button
              onClick={() => setEditing(!editing)}
              className="px-4 py-2 border border-slate-300 hover:border-slate-400 rounded-xl text-xs font-bold text-slate-700 transition-colors shadow-sm"
            >
              {editing ? 'Cancel' : 'Edit Info'}
            </button>
          </div>

          {!editing ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-3.5 p-3.5 bg-slate-50 rounded-2xl border border-slate-100">
                  <User className="w-5 h-5 text-indigo-600 shrink-0" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Full Name</span>
                    <span className="text-sm font-bold text-slate-800">{student.name}</span>
                  </div>
                </div>
                <div className="flex items-center gap-3.5 p-3.5 bg-slate-50 rounded-2xl border border-slate-100">
                  <Shield className="w-5 h-5 text-indigo-600 shrink-0" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Target Class</span>
                    <span className="text-sm font-bold text-slate-800">{student.class}</span>
                  </div>
                </div>
                <div className="flex items-center gap-3.5 p-3.5 bg-slate-50 rounded-2xl border border-slate-100">
                  <Phone className="w-5 h-5 text-indigo-600 shrink-0" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Contact Phone</span>
                    <span className="text-sm font-bold text-slate-800">{student.phone}</span>
                  </div>
                </div>
                <div className="flex items-center gap-3.5 p-3.5 bg-slate-50 rounded-2xl border border-slate-100">
                  <Mail className="w-5 h-5 text-indigo-600 shrink-0" />
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Registered Email</span>
                    <span className="text-sm font-bold text-slate-800">{student.email}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3.5 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                <School className="w-5 h-5 text-indigo-600 shrink-0" />
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">School Name</span>
                  <span className="text-sm font-bold text-slate-800">{student.schoolName || 'Not Specified'}</span>
                </div>
              </div>

              <div className="flex items-start gap-3.5 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                <MapPin className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Home Address</span>
                  <span className="text-sm font-medium text-slate-700 leading-relaxed">{student.address || 'Not Specified'}</span>
                </div>
              </div>
            </div>
          ) : (
            <form onSubmit={handleUpdate} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Full Name</label>
                <input required name="name" type="text" defaultValue={student.name} className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Contact Phone</label>
                  <input required name="phone" type="tel" defaultValue={student.phone} className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Email</label>
                  <input required name="email" type="email" defaultValue={student.email} className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">School Name</label>
                <input required name="schoolName" type="text" defaultValue={student.schoolName || ''} className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Residential Address</label>
                <textarea required name="address" rows={2} defaultValue={student.address || ''} className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-sm resize-none" />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button type="button" onClick={() => setEditing(false)} className="px-4 py-2 text-slate-500 text-xs font-bold hover:bg-slate-50 rounded-xl">Cancel</button>
                <button type="submit" className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md">Save Changes</button>
              </div>
            </form>
          )}
        </div>

        {/* Right Side: Digital ID Card Preview */}
        <div className="lg:col-span-5 space-y-6">
          <h2 className="text-sm font-extrabold text-slate-400 uppercase tracking-widest px-1">Digital Student ID Card</h2>
          
          {/* Gorgeous Apple Wallet Style Card layout */}
          <div className="bg-gradient-to-br from-indigo-600 via-indigo-700 to-slate-900 text-white rounded-3xl p-6.5 shadow-2xl border border-indigo-400/20 relative overflow-hidden space-y-6 aspect-[1.58/1] max-w-sm mx-auto group">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_30%,rgba(255,255,255,0.08),transparent)]" />
            
            {/* ID Card top */}
            <div className="flex justify-between items-start relative z-10">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center font-bold text-white text-sm">D</div>
                <div>
                  <h3 className="font-extrabold text-xs tracking-tight">Dhruv Coaching Classes</h3>
                  <span className="text-[8px] uppercase font-bold text-indigo-200 tracking-wider">Student ID Passport</span>
                </div>
              </div>
              <CreditCard className="w-5 h-5 text-indigo-300" />
            </div>

            {/* ID Card middle info */}
            <div className="flex items-center gap-4 relative z-10 pt-2">
              <div className="w-16 h-16 bg-white/10 rounded-2xl border border-white/20 flex items-center justify-center font-bold text-2xl text-white shadow-md uppercase">
                {student.name[0]}
              </div>
              <div className="space-y-1">
                <h4 className="font-extrabold text-lg tracking-tight leading-none">{student.name}</h4>
                <p className="text-[10px] text-indigo-200 uppercase font-bold">Class Section: {student.class}</p>
                <p className="text-[9px] text-slate-300">Enrollment Date: {new Date(student.enrollmentDate).toLocaleDateString()}</p>
              </div>
            </div>

            {/* ID Card bottom with barcode/access specs */}
            <div className="flex justify-between items-end pt-3 relative z-10">
              <div>
                <span className="text-[8px] text-indigo-300 uppercase font-bold block">Digital Passport ID</span>
                <span className="font-mono font-bold text-xs tracking-wider">DCC-2026-{(student.id || 'N/A').substring(0,6).toUpperCase()}</span>
              </div>
              <span className="bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest">
                VERIFIED ACTIVE
              </span>
            </div>
          </div>

          <button
            onClick={downloadIDCard}
            className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-slate-900 hover:bg-black text-white font-bold rounded-2xl shadow-lg transition-all text-sm max-w-sm mx-auto"
          >
            <Download className="w-4 h-4" /> Download ID Card PDF
          </button>
        </div>

      </div>

    </div>
  );
}
