import React, { useEffect, useState } from 'react';
import { collection, getDocs, addDoc, query, where, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { Student } from './types';
import { useAuth } from './AuthContext';
import { Search, Plus, Filter, X, Edit, Trash2 } from 'lucide-react';

export default function Students() {
  const { role } = useAuth();
  const [students, setStudents] = useState<Student[]>([]);
  const [batches, setBatches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [filterClass, setFilterClass] = useState('');
  const [filterCourse, setFilterCourse] = useState('');

  const fetchBatches = async () => {
    try {
      const snap = await getDocs(collection(db, 'batches'));
      setBatches(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (error) {
      console.error('Error fetching batches:', error);
    }
  };

  const fetchStudents = async () => {
    setLoading(true);
    try {
      let q = collection(db, 'students') as any;
      
      if (filterClass && filterCourse) {
        q = query(collection(db, 'students'), where('class', '==', filterClass), where('course', '==', filterCourse));
      } else if (filterClass) {
        q = query(collection(db, 'students'), where('class', '==', filterClass));
      } else if (filterCourse) {
        q = query(collection(db, 'students'), where('course', '==', filterCourse));
      }

      const snap = await getDocs(q);
      setStudents(snap.docs.map(d => ({ id: d.id, ... (d.data() as any) } as Student)));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, 'students');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBatches();
    fetchStudents();
  }, [filterClass, filterCourse]);

  const handleAdd = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const newStudent = {
      userId: '', // Intentionally blank, linked later if user signs up
      name: fd.get('name') as string,
      class: fd.get('class') as string,
      course: fd.get('course') as string,
      enrollmentDate: new Date().toISOString(),
      phone: fd.get('phone') as string,
      email: fd.get('email') as string,
      address: fd.get('address') as string,
      schoolName: fd.get('schoolName') as string,
      batchId: fd.get('batchId') as string || '',
    };

    try {
      const docRef = await addDoc(collection(db, 'students'), newStudent);
      
      // Auto fee generation based on predefined course fees
      const feeQuery = query(
         collection(db, 'courseFees'), 
         where('class', '==', newStudent.class),
         where('course', '==', newStudent.course)
      );
      const feeSnap = await getDocs(feeQuery);
      
      if (!feeSnap.empty) {
        const feeData = feeSnap.docs[0].data();
        const dueDate = new Date();
        dueDate.setMonth(dueDate.getMonth() + 1); // Due in 1 month by default
        
        await addDoc(collection(db, 'fees'), {
          studentId: docRef.id,
          amount: feeData.amount,
          status: 'pending',
          dueDate: dueDate.toISOString(),
          paymentDate: ''
        });
      }

      setShowAddModal(false);
      fetchStudents();
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'students');
    }
  };

  const handleEditSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!editingStudent || !editingStudent.id) return;
    const fd = new FormData(e.currentTarget);
    const updatedStudent: any = {
      ...editingStudent,
      name: fd.get('name') as string,
      class: fd.get('class') as string,
      course: fd.get('course') as string,
      phone: fd.get('phone') as string,
      email: fd.get('email') as string,
      schoolName: fd.get('schoolName') as string,
      address: fd.get('address') as string,
      batchId: fd.get('batchId') as string || '',
    };
    
    // Remove document ID from the payload body before updating in firestore
    delete updatedStudent.id;

    try {
      await updateDoc(doc(db, 'students', editingStudent.id), updatedStudent);
      setEditingStudent(null);
      fetchStudents();
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'students');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this student record?')) return;
    try {
      await deleteDoc(doc(db, 'students', id));
      fetchStudents();
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'students');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-900">Students</h1>
        {(role === 'admin' || role === 'teacher') && (
          <button 
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Student
          </button>
        )}
      </div>

      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 flex flex-col sm:flex-row gap-4 items-center">
        <div className="flex items-center gap-2 text-slate-500 font-medium">
          <Filter className="w-4 h-4" />
          Filters:
        </div>
        <select 
          className="border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 outline-none w-full sm:w-auto"
          value={filterClass} onChange={(e) => setFilterClass(e.target.value)}
        >
          <option value="">All Classes</option>
          {[...Array(12)].map((_, i) => (
            <option key={i+1} value={`Class ${i+1}`}>Class {i+1}</option>
          ))}
        </select>
        <select 
          className="border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 outline-none w-full sm:w-auto"
          value={filterCourse} onChange={(e) => setFilterCourse(e.target.value)}
        >
          <option value="">All Courses</option>
          <option value="Mathematics">Mathematics</option>
          <option value="Science">Science</option>
          <option value="Crash Course">Crash Course</option>
          <option value="All Subjects">All Subjects</option>
        </select>
        {(filterClass || filterCourse) && (
          <button onClick={() => { setFilterClass(''); setFilterCourse(''); }} className="text-sm text-slate-500 hover:text-slate-800 underline">
            Clear Filters
          </button>
        )}
      </div>

      {loading ? (
        <div className="text-center py-12 text-slate-500">Loading students...</div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
          <div className="overflow-x-auto">
             <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 font-medium uppercase text-xs sticky top-0">
                <tr className="border-b border-slate-200">
                  <th className="px-4 py-3">Name</th>
                  <th className="px-4 py-3">Class</th>
                  <th className="px-4 py-3">Course</th>
                  <th className="px-4 py-3">Batch</th>
                  <th className="px-4 py-3">Phone</th>
                  <th className="px-4 py-3">Enrolled</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {students.length === 0 ? (
                  <tr><td colSpan={7} className="px-4 py-8 text-center text-slate-500">No students found.</td></tr>
                ) : (
                  students.map(student => {
                    const matchedBatch = batches.find(b => b.id === student.batchId);
                    return (
                      <tr key={student.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-4 py-3 font-medium text-slate-900">{student.name}</td>
                        <td className="px-4 py-3 text-slate-600">{student.class}</td>
                        <td className="px-4 py-3 text-slate-600">
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-indigo-100 text-indigo-800 uppercase">
                            {student.course}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-slate-600 font-semibold text-slate-700">
                          {matchedBatch ? `${matchedBatch.class} - ${matchedBatch.name}` : <span className="text-slate-400 text-xs italic">Unassigned</span>}
                        </td>
                        <td className="px-4 py-3 text-slate-600">{student.phone}</td>
                        <td className="px-4 py-3 text-slate-600">{new Date(student.enrollmentDate).toLocaleDateString()}</td>
                        <td className="px-4 py-3 text-right">
                          <div className="flex justify-end gap-1">
                            <button
                              onClick={() => setEditingStudent(student)}
                              className="p-1 text-slate-400 hover:text-indigo-600 rounded hover:bg-indigo-50 transition-colors"
                              title="Edit Student"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDelete(student.id!)}
                              className="p-1 text-slate-400 hover:text-red-600 rounded hover:bg-red-50 transition-colors"
                              title="Delete Student"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
              <h3 className="font-bold text-lg text-slate-900">Add New Student</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAdd} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                <input required name="name" type="text" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="John Doe" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Class</label>
                  <select required name="class" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none">
                    {[...Array(12)].map((_, i) => (
                      <option key={i+1} value={`Class ${i+1}`}>Class {i+1}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Course</label>
                  <select required name="course" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none">
                    <option value="Mathematics">Mathematics</option>
                    <option value="Science">Science</option>
                    <option value="Crash Course">Crash Course</option>
                    <option value="All Subjects">All Subjects</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
                  <input required name="phone" type="tel" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="+91 9876543210" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
                  <input required name="email" type="email" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="john@example.com" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">School Name</label>
                <input required name="schoolName" type="text" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="School Name" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Address</label>
                <textarea required name="address" rows={2} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none resize-none" placeholder="Full Residential Address" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Batch Assignment</label>
                <select name="batchId" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none bg-white">
                  <option value="">No Batch Assigned</option>
                  {batches.map(b => (
                    <option key={b.id} value={b.id}>{b.class} - {b.name}</option>
                  ))}
                </select>
              </div>
              <div className="pt-4 flex justify-end gap-3">
                <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 text-slate-600 font-medium hover:bg-slate-50 rounded-lg">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700">Save Student</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {editingStudent && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
              <h3 className="font-bold text-lg text-slate-900">Edit Student Details</h3>
              <button onClick={() => setEditingStudent(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleEditSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                <input required name="name" type="text" defaultValue={editingStudent.name} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Class</label>
                  <select required name="class" defaultValue={editingStudent.class} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none">
                    {[...Array(12)].map((_, i) => (
                      <option key={i+1} value={`Class ${i+1}`}>Class {i+1}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Course</label>
                  <select required name="course" defaultValue={editingStudent.course} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none">
                    <option value="Mathematics">Mathematics</option>
                    <option value="Science">Science</option>
                    <option value="Crash Course">Crash Course</option>
                    <option value="All Subjects">All Subjects</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
                  <input required name="phone" type="tel" defaultValue={editingStudent.phone} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
                  <input required name="email" type="email" defaultValue={editingStudent.email} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">School Name</label>
                <input required name="schoolName" type="text" defaultValue={editingStudent.schoolName || ''} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Address</label>
                <textarea required name="address" rows={2} defaultValue={editingStudent.address || ''} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none resize-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Batch Assignment</label>
                <select name="batchId" defaultValue={editingStudent.batchId || ''} className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none bg-white">
                  <option value="">No Batch Assigned</option>
                  {batches.map(b => (
                    <option key={b.id} value={b.id}>{b.class} - {b.name}</option>
                  ))}
                </select>
              </div>
              <div className="pt-4 flex justify-end gap-3">
                <button type="button" onClick={() => setEditingStudent(null)} className="px-4 py-2 text-slate-600 font-medium hover:bg-slate-50 rounded-lg">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700">Save Changes</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
