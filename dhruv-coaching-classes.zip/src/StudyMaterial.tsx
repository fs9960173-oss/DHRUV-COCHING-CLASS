import React, { useState, useEffect } from 'react';
import { collection, getDocs, addDoc, deleteDoc, doc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { useAuth } from './AuthContext';
import { Trash2, Plus, X, FolderOpen, ExternalLink, FileText } from 'lucide-react';

interface Material {
  id?: string;
  title: string;
  type: string;
  subject: string;
  batchName?: string;
  fileUrl?: string;
}

const DEFAULT_MATERIALS = [
  { title: 'Physics Formula Sheet', type: 'pdf', subject: 'Physics', batchName: 'JEE Advanced 2026', fileUrl: 'https://arxiv.org/pdf/quant-ph/0402001.pdf' },
  { title: 'Organic Chem Notes', type: 'pdf', subject: 'Chemistry', batchName: 'NEET 2026 Foundation', fileUrl: 'https://arxiv.org/pdf/quant-ph/0402001.pdf' },
  { title: 'Biology Mind Map', type: 'pdf', subject: 'Biology', batchName: 'NEET 2026 Foundation', fileUrl: 'https://arxiv.org/pdf/quant-ph/0402001.pdf' }
];

export default function StudyMaterial() {
  const { role } = useAuth();
  const [materials, setMaterials] = useState<Material[]>([]);
  const [batches, setBatches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);

  // Form states
  const [newTitle, setNewTitle] = useState('');
  const [newType, setNewType] = useState('pdf');
  const [newSubject, setNewSubject] = useState('');
  const [newBatch, setNewBatch] = useState('');
  const [newFileUrl, setNewFileUrl] = useState('https://arxiv.org/pdf/quant-ph/0402001.pdf');

  const isStaff = role === 'admin' || role === 'teacher';

  const fetchMaterials = async () => {
    try {
      setLoading(true);
      const snap = await getDocs(collection(db, 'study_material_simple'));
      let fetched = snap.docs.map(d => ({ id: d.id, ...d.data() } as Material));

      const bSnap = await getDocs(collection(db, 'batches'));
      const fetchedBatches = bSnap.docs.map(d => ({ id: d.id, ...d.data() }));
      setBatches(fetchedBatches);
      if (fetchedBatches.length > 0) {
        setNewBatch(fetchedBatches[0].name || fetchedBatches[0].class);
      } else {
        setNewBatch('JEE Advanced 2026');
      }

      if (fetched.length === 0) {
        // Auto-seed
        for (const item of DEFAULT_MATERIALS) {
          const docRef = await addDoc(collection(db, 'study_material_simple'), item);
          fetched.push({ id: docRef.id, ...item });
        }
      }

      setMaterials(fetched);
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'study_material_simple');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMaterials();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newSubject.trim()) return;

    const newMat = {
      title: newTitle.trim(),
      type: newType,
      subject: newSubject.trim(),
      batchName: newBatch,
      fileUrl: newFileUrl.trim()
    };

    try {
      await addDoc(collection(db, 'study_material_simple'), newMat);
      setNewTitle('');
      setNewSubject('');
      setNewFileUrl('https://arxiv.org/pdf/quant-ph/0402001.pdf');
      setShowAddForm(false);
      fetchMaterials();
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'study_material_simple');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this study material?')) return;
    try {
      await deleteDoc(doc(db, 'study_material_simple', id));
      fetchMaterials();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'study_material_simple');
    }
  };

  if (loading) {
    return (
      <div className="min-h-[400px] flex flex-col items-center justify-center font-sans">
        <div className="w-10 h-10 border-4 border-[#0070f3] border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-slate-500 font-semibold text-sm">Loading study materials...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12 font-sans select-none">
      {/* Page Header */}
      <div className="flex justify-between items-center">
        <div>
          <span className="text-xs font-black text-slate-400 uppercase tracking-widest block mb-0.5">ADMIN</span>
          <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight">Study Material</h1>
          <p className="text-slate-500 text-sm mt-1 font-semibold">Upload PDFs, notes and files</p>
        </div>
        {isStaff && (
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center gap-2 px-6 py-3 bg-[#0070f3] hover:bg-[#0060df] text-white rounded-full font-bold text-sm shadow-md shadow-blue-500/10 active:scale-[0.98] transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Material</span>
          </button>
        )}
      </div>

      {/* Table Section */}
      <div className="bg-white rounded-[32px] border border-slate-200/50 shadow-sm overflow-hidden flex flex-col animate-fadeIn">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100">
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs w-[35%]">Title</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Type</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Batch</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Subject</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">File Link</th>
                {isStaff && <th className="px-8 py-5 w-[10%]"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {materials.map((m) => (
                <tr key={m.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-8 py-5 text-slate-800 font-semibold text-sm flex items-center gap-2.5">
                    <span className="p-1.5 bg-blue-50 text-[#0070f3] rounded-lg">
                      <FileText className="w-3.5 h-3.5" />
                    </span>
                    {m.title}
                  </td>
                  <td className="px-8 py-5 text-slate-500 font-bold uppercase text-xs tracking-wider">
                    <span className="bg-blue-50 text-[#0070f3] px-2.5 py-1 rounded-md">
                      {m.type}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-slate-500 font-semibold text-sm">
                    <span className="bg-slate-100 px-3 py-1 rounded-full text-xs text-slate-700 font-bold">
                      {m.batchName || 'General'}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-slate-500 font-medium text-sm">{m.subject}</td>
                  <td className="px-8 py-5">
                    {m.fileUrl ? (
                      <a
                        href={m.fileUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-1 text-[#0070f3] hover:underline font-bold text-xs"
                      >
                        Download PDF <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    ) : (
                      <span className="text-slate-400 text-xs">-</span>
                    )}
                  </td>
                  {isStaff && (
                    <td className="px-8 py-5 text-right">
                      <button
                        onClick={() => handleDelete(m.id!)}
                        className="text-slate-400 hover:text-red-500 p-2 rounded-lg hover:bg-red-50/50 transition-all cursor-pointer"
                        title="Delete Material"
                      >
                        <Trash2 className="w-5 h-5" strokeWidth={1.5} />
                      </button>
                    </td>
                  )}
                </tr>
              ))}
              {materials.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-8 py-12 text-center text-slate-400 font-medium text-sm">
                    No study materials available.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Material Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-3xl shadow-xl w-full max-w-md overflow-hidden border border-slate-100 p-6 space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-950 text-lg flex items-center gap-2">
                <FolderOpen className="w-5 h-5 text-[#0070f3]" />
                Add Material
              </h3>
              <button onClick={() => setShowAddForm(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Document Title</label>
                <input
                  required
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium placeholder-slate-400 text-sm"
                  placeholder="e.g. Mechanics Formula Sheet"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Type</label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm bg-white"
                  >
                    <option value="pdf">PDF</option>
                    <option value="doc">Word Doc</option>
                    <option value="slides">PowerPoint</option>
                    <option value="zip">ZIP Archive</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Subject</label>
                  <input
                    required
                    type="text"
                    value={newSubject}
                    onChange={(e) => setNewSubject(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium placeholder-slate-400 text-sm"
                    placeholder="e.g. Physics"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Batch</label>
                <select
                  required
                  value={newBatch}
                  onChange={(e) => setNewBatch(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm bg-white"
                >
                  {batches.map((b) => (
                    <option key={b.id} value={b.name || b.class}>
                      {b.name || b.class}
                    </option>
                  ))}
                  {batches.length === 0 && (
                    <>
                      <option value="JEE Advanced 2026">JEE Advanced 2026</option>
                      <option value="NEET 2026 Foundation">NEET 2026 Foundation</option>
                    </>
                  )}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">File Link / URL</label>
                <input
                  required
                  type="url"
                  value={newFileUrl}
                  onChange={(e) => setNewFileUrl(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm"
                  placeholder="e.g. https://example.com/file.pdf"
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-5 py-2.5 text-slate-500 font-bold text-sm hover:bg-slate-50 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#0070f3] hover:bg-[#0060df] text-white font-bold text-sm rounded-xl shadow-md cursor-pointer"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
