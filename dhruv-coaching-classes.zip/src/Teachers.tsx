import React, { useEffect, useState } from 'react';
import { collection, getDocs, addDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { Teacher } from './types';
import { useAuth } from './AuthContext';
import { Plus, X, UserCircle2 } from 'lucide-react';

export default function Teachers() {
  const { role } = useAuth();
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);

  const fetchTeachers = async () => {
    setLoading(true);
    try {
      const snap = await getDocs(collection(db, 'teachers'));
      setTeachers(snap.docs.map(d => ({ id: d.id, ... (d.data() as any) } as Teacher)));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, 'teachers');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTeachers();
  }, []);

  const handleAdd = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const newTeacher = {
      name: fd.get('name') as string,
      subject: fd.get('subject') as string,
      phone: fd.get('phone') as string,
      email: fd.get('email') as string,
    };

    try {
      await addDoc(collection(db, 'teachers'), newTeacher);
      setShowAddModal(false);
      fetchTeachers();
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'teachers');
    }
  };

  if (role !== 'admin') {
    return <div className="p-8 text-center text-slate-500">You do not have permission to view this page.</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-900">Teachers Directory</h1>
        <button 
          onClick={() => setShowAddModal(true)}
          className="flex items-center justify-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add Teacher
        </button>
      </div>

      {loading ? (
        <div className="text-center py-12 text-slate-500">Loading teachers...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {teachers.map(teacher => (
            <div key={teacher.id} className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 flex flex-col items-center text-center hover:border-indigo-300 transition-colors">
              <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-slate-400 mb-4 border border-slate-100">
                <UserCircle2 className="w-10 h-10" />
              </div>
              <h3 className="font-bold text-slate-900 text-lg">{teacher.name}</h3>
              <p className="text-indigo-600 font-medium text-sm mb-4">{teacher.subject}</p>
              <div className="w-full space-y-2 text-sm text-slate-600 text-left bg-slate-50 rounded-lg p-3 border border-slate-100">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Phone</span>
                  <span className="font-medium text-slate-700">{teacher.phone}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Email</span>
                  <span className="font-medium text-slate-700 truncate ml-2">{teacher.email}</span>
                </div>
              </div>
            </div>
          ))}
          {teachers.length === 0 && (
            <div className="col-span-full py-12 text-center text-slate-500 bg-white rounded-xl border border-dashed border-slate-300">
              No teachers added yet.
            </div>
          )}
        </div>
      )}

      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
              <h3 className="font-bold text-lg text-slate-900">Add New Teacher</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAdd} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
                <input required name="name" type="text" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="Jane Smith" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Subject</label>
                <input required name="subject" type="text" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="Physics" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
                <input required name="phone" type="tel" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="+91 9876543210" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
                <input required name="email" type="email" className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" placeholder="jane@example.com" />
              </div>
              <div className="pt-4 flex justify-end gap-3">
                <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 text-slate-600 font-medium hover:bg-slate-50 rounded-lg">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700">Save Teacher</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
