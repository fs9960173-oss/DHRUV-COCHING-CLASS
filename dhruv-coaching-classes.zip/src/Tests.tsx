import React, { useState, useEffect } from 'react';
import { collection, getDocs, addDoc, deleteDoc, doc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { useAuth } from './AuthContext';
import { Trash2, Plus, X, GraduationCap, Calendar, Clock, ListChecks } from 'lucide-react';

interface TestItem {
  id?: string;
  title: string;
  subject: string;
  duration: string;
  qs: number;
  batchName?: string;
  date?: string;
}

const DEFAULT_TESTS = [
  { title: 'Physics Weekly Test 1', subject: 'Physics', duration: '60 Min', qs: 15, batchName: 'JEE Advanced 2026', date: '2026-07-20' },
  { title: 'Chemistry MCQ Practice', subject: 'Chemistry', duration: '30 Min', qs: 10, batchName: 'NEET 2026 Foundation', date: '2026-07-19' }
];

export default function Tests() {
  const { role } = useAuth();
  const [tests, setTests] = useState<TestItem[]>([]);
  const [batches, setBatches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);

  // Form states
  const [newTitle, setNewTitle] = useState('');
  const [newSubject, setNewSubject] = useState('');
  const [newDuration, setNewDuration] = useState('60 Min');
  const [newQs, setNewQs] = useState(15);
  const [newBatch, setNewBatch] = useState('');
  const [newDate, setNewDate] = useState('');

  const isStaff = role === 'admin' || role === 'teacher';

  const fetchTests = async () => {
    try {
      setLoading(true);
      const snap = await getDocs(collection(db, 'tests_simple'));
      let fetched = snap.docs.map(d => ({ id: d.id, ...d.data() } as TestItem));

      const bSnap = await getDocs(collection(db, 'batches'));
      const fetchedBatches = bSnap.docs.map(d => ({ id: d.id, ...d.data() }));
      setBatches(fetchedBatches);
      if (fetchedBatches.length > 0) {
        setNewBatch(fetchedBatches[0].name || fetchedBatches[0].class);
      } else {
        setNewBatch('JEE Advanced 2026');
      }

      if (fetched.length === 0) {
        // Auto-seed
        for (const item of DEFAULT_TESTS) {
          const docRef = await addDoc(collection(db, 'tests_simple'), item);
          fetched.push({ id: docRef.id, ...item });
        }
      }

      setTests(fetched);
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'tests_simple');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTests();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newSubject.trim() || !newDate) return;

    const newItem = {
      title: newTitle.trim(),
      subject: newSubject.trim(),
      duration: newDuration.trim(),
      qs: Number(newQs),
      batchName: newBatch,
      date: newDate
    };

    try {
      await addDoc(collection(db, 'tests_simple'), newItem);
      setNewTitle('');
      setNewSubject('');
      setNewDuration('60 Min');
      setNewQs(15);
      setNewDate('');
      setShowAddForm(false);
      fetchTests();
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'tests_simple');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this test?')) return;
    try {
      await deleteDoc(doc(db, 'tests_simple', id));
      fetchTests();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'tests_simple');
    }
  };

  if (loading) {
    return (
      <div className="min-h-[400px] flex flex-col items-center justify-center font-sans">
        <div className="w-10 h-10 border-4 border-[#0070f3] border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-slate-500 font-semibold text-sm">Loading online tests...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12 font-sans select-none">
      {/* Page Header */}
      <div className="flex justify-between items-center">
        <div>
          <span className="text-xs font-black text-slate-400 uppercase tracking-widest block mb-0.5">ADMIN</span>
          <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight">Tests</h1>
          <p className="text-slate-500 text-sm mt-1 font-semibold">Create MCQ tests with auto-grading</p>
        </div>
        {isStaff && (
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center gap-2 px-6 py-3 bg-[#0070f3] hover:bg-[#0060df] text-white rounded-full font-bold text-sm shadow-md shadow-blue-500/10 active:scale-[0.98] transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create Test</span>
          </button>
        )}
      </div>

      {/* Table Section */}
      <div className="bg-white rounded-[32px] border border-slate-200/50 shadow-sm overflow-hidden flex flex-col animate-fadeIn">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100">
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs w-[35%]">Test Title</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Subject</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Batch</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Date</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Duration</th>
                <th className="px-8 py-5 text-slate-400 font-bold uppercase tracking-wider text-xs">Questions</th>
                {isStaff && <th className="px-8 py-5 w-[10%]"></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {tests.map((t) => (
                <tr key={t.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-8 py-5 text-slate-800 font-semibold text-sm flex items-center gap-2">
                    <span className="p-1.5 bg-blue-50 text-[#0070f3] rounded-lg">
                      <GraduationCap className="w-4 h-4" />
                    </span>
                    {t.title}
                  </td>
                  <td className="px-8 py-5 text-slate-600 font-semibold text-sm">{t.subject}</td>
                  <td className="px-8 py-5 text-slate-500 font-semibold text-sm">
                    <span className="bg-slate-100 px-3 py-1 rounded-full text-xs text-slate-700 font-bold">
                      {t.batchName || 'General'}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-slate-500 font-medium text-sm flex items-center gap-1.5 mt-1.5">
                    <Calendar className="w-4 h-4 text-slate-400" />
                    {t.date || 'TBD'}
                  </td>
                  <td className="px-8 py-5 text-slate-500 font-semibold text-sm">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {t.duration}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-slate-500 font-bold text-sm">
                    <span className="flex items-center gap-1">
                      <ListChecks className="w-3.5 h-3.5 text-[#0070f3]" />
                      {t.qs} Qs
                    </span>
                  </td>
                  {isStaff && (
                    <td className="px-8 py-5 text-right">
                      <button
                        onClick={() => handleDelete(t.id!)}
                        className="text-slate-400 hover:text-red-500 p-2 rounded-lg hover:bg-red-50/50 transition-all cursor-pointer"
                        title="Delete Test"
                      >
                        <Trash2 className="w-5 h-5" strokeWidth={1.5} />
                      </button>
                    </td>
                  )}
                </tr>
              ))}
              {tests.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-8 py-12 text-center text-slate-400 font-medium text-sm">
                    No tests scheduled.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Test Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-3xl shadow-xl w-full max-w-md overflow-hidden border border-slate-100 p-6 space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-950 text-lg flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-[#0070f3]" />
                Create Test
              </h3>
              <button onClick={() => setShowAddForm(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Test Title</label>
                <input
                  required
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium placeholder-slate-400 text-sm"
                  placeholder="e.g. Weekly Assessment 1"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Subject</label>
                  <input
                    required
                    type="text"
                    value={newSubject}
                    onChange={(e) => setNewSubject(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium placeholder-slate-400 text-sm"
                    placeholder="e.g. Physics"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Duration</label>
                  <input
                    required
                    type="text"
                    value={newDuration}
                    onChange={(e) => setNewDuration(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm"
                    placeholder="e.g., 60 Min"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Batch</label>
                <select
                  required
                  value={newBatch}
                  onChange={(e) => setNewBatch(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm bg-white"
                >
                  {batches.map((b) => (
                    <option key={b.id} value={b.name || b.class}>
                      {b.name || b.class}
                    </option>
                  ))}
                  {batches.length === 0 && (
                    <>
                      <option value="JEE Advanced 2026">JEE Advanced 2026</option>
                      <option value="NEET 2026 Foundation">NEET 2026 Foundation</option>
                    </>
                  )}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">No. of Questions</label>
                  <input
                    required
                    type="number"
                    value={newQs}
                    onChange={(e) => setNewQs(Number(e.target.value))}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm"
                    placeholder="15"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1.5">Date</label>
                  <input
                    required
                    type="date"
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 focus:border-[#0070f3] rounded-xl focus:ring-2 focus:ring-[#0070f3]/10 outline-none text-slate-900 font-medium text-sm"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-5 py-2.5 text-slate-500 font-bold text-sm hover:bg-slate-50 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#0070f3] hover:bg-[#0060df] text-white font-bold text-sm rounded-xl shadow-md cursor-pointer"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
