import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, addDoc, deleteDoc, doc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import { useAuth } from './AuthContext';
import { Timetable, Batch } from './types';
import { Calendar, Clock, Plus, X, Trash2, BookOpen, User, GraduationCap } from 'lucide-react';

export default function TimetablePage() {
  const { role, user, studentBatchId } = useAuth();
  const [timetables, setTimetables] = useState<Timetable[]>([]);
  const [batches, setBatches] = useState<Batch[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const [selectedDay, setSelectedDay] = useState('Monday');

  const isStaff = role === 'admin' || role === 'teacher';

  const fetchData = async () => {
    try {
      setLoading(true);
      const tSnap = await getDocs(collection(db, 'timetable'));
      const bSnap = await getDocs(collection(db, 'batches'));

      const fetchedTimetables = tSnap.docs.map(d => ({ id: d.id, ...d.data() } as Timetable));
      const fetchedBatches = bSnap.docs.map(d => ({ id: d.id, ...d.data() } as Batch));

      setBatches(fetchedBatches);

      if (!isStaff && user) {
        const sSnap = await getDocs(collection(db, 'students'));
        const studentProfile = sSnap.docs.map(d => d.data()).find(s => s.userId === user.uid);
        
        const activeBatchId = studentProfile?.batchId || studentBatchId;

        if (activeBatchId) {
          // Show timetables belonging specifically to student's assigned batch
          setTimetables(fetchedTimetables.filter(t => t.batchId === activeBatchId));
        } else if (studentProfile) {
          const matchingBatches = fetchedBatches.filter(b => b.class === studentProfile.class);
          const bIds = matchingBatches.map(b => b.id);
          setTimetables(fetchedTimetables.filter(t => bIds.includes(t.batchId)));
        } else {
          setTimetables([]);
        }
      } else {
        setTimetables(fetchedTimetables);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, 'timetable');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [role, user]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const timetableData = {
      batchId: fd.get('batchId') as string,
      day: fd.get('day') as string,
      subject: fd.get('subject') as string,
      time: fd.get('time') as string,
      teacherName: fd.get('teacherName') as string
    };

    try {
      await addDoc(collection(db, 'timetable'), timetableData);
      setShowForm(false);
      fetchData();
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'timetable');
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this schedule period?')) return;
    try {
      await deleteDoc(doc(db, 'timetable', id));
      fetchData();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'timetable');
    }
  };

  if (loading) {
    return <div className="p-8 text-center text-slate-500">Loading daily schedule structures...</div>;
  }

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-white p-6 rounded-2xl shadow-sm border border-slate-200 gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
            <Calendar className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Weekly Class Timetable</h1>
            <p className="text-sm text-slate-500">Coordinate and check lecture slots, timings, and class mentors.</p>
          </div>
        </div>
        {isStaff && (
          <button
            onClick={() => setShowForm(true)}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold flex items-center gap-2 text-sm shadow-md"
          >
            <Plus className="w-4 h-4" /> Add Period Slot
          </button>
        )}
      </div>

      {/* Timetable Period Addition Form */}
      {showForm && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-md flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden border border-slate-100">
            <div className="px-6 py-4.5 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
              <h3 className="font-extrabold text-slate-900 text-base">Schedule Lecture Slot</h3>
              <button onClick={() => setShowForm(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Target Batch</label>
                <select required name="batchId" className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl outline-none bg-white text-sm focus:ring-2 focus:ring-indigo-500">
                  {batches.map(b => (
                    <option key={b.id} value={b.id}>{b.class} - {b.name}</option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Weekday</label>
                  <select required name="day" className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl outline-none bg-white text-sm focus:ring-2 focus:ring-indigo-500">
                    {daysOfWeek.map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Timing</label>
                  <input required name="time" type="text" className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl outline-none text-sm focus:ring-2 focus:ring-indigo-500" placeholder="e.g. 4:00 - 5:30 PM" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Subject</label>
                  <input required name="subject" type="text" className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl outline-none text-sm focus:ring-2 focus:ring-indigo-500" placeholder="e.g. Mathematics" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Lecturer Name</label>
                  <input required name="teacherName" type="text" className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl outline-none text-sm focus:ring-2 focus:ring-indigo-500" placeholder="e.g. Dr. Verma" />
                </div>
              </div>
              <div className="pt-4 flex justify-end gap-3 border-t border-slate-100">
                <button type="button" onClick={() => setShowForm(false)} className="px-4 py-2.5 text-slate-500 font-bold text-sm hover:bg-slate-50 rounded-xl transition-colors">Cancel</button>
                <button type="submit" className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-sm shadow-md">Schedule slot</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Weekday selector bar */}
      <div className="flex flex-wrap items-center justify-center gap-2.5 bg-white p-3 rounded-2xl border border-slate-200 shadow-sm max-w-xl mx-auto">
        {daysOfWeek.map(day => (
          <button
            key={day}
            onClick={() => setSelectedDay(day)}
            className={`px-4.5 py-2.5 rounded-xl text-xs font-extrabold transition-all ${
              selectedDay === day 
                ? 'bg-indigo-600 text-white shadow-md' 
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-800'
            }`}
          >
            {day.substring(0,3)}
          </button>
        ))}
      </div>

      {/* Timetable Period Cards Grid */}
      <div className="max-w-xl mx-auto space-y-4">
        {timetables.filter(t => t.day === selectedDay).length === 0 ? (
          <div className="py-16 text-center bg-white rounded-3xl border border-slate-200 shadow-sm">
            <Calendar className="w-16 h-16 text-slate-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-900">No classes scheduled</h3>
            <p className="text-slate-500 text-xs mt-0.5">There are no periods or lectures assigned for {selectedDay}.</p>
          </div>
        ) : (
          timetables.filter(t => t.day === selectedDay).map(period => {
            const matchedBatch = batches.find(b => b.id === period.batchId);
            return (
              <div key={period.id} className="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-all flex items-center justify-between gap-4 group">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center shrink-0 border border-indigo-100">
                    <BookOpen className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 font-bold uppercase tracking-wider rounded">
                      {matchedBatch ? `${matchedBatch.class} • ${matchedBatch.name}` : 'Coaching Batch'}
                    </span>
                    <h3 className="font-extrabold text-slate-900 text-base mt-1.5">{period.subject}</h3>
                    <div className="flex items-center gap-3.5 mt-2 text-xs text-slate-500 font-semibold">
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4 text-indigo-500 shrink-0" />
                        {period.time}
                      </span>
                      <span className="flex items-center gap-1">
                        <GraduationCap className="w-4 h-4 text-emerald-500 shrink-0" />
                        Mentor: {period.teacherName}
                      </span>
                    </div>
                  </div>
                </div>

                {isStaff && (
                  <button 
                    onClick={() => handleDelete(period.id!)}
                    className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-opacity opacity-0 group-hover:opacity-100"
                    title="Delete period"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            );
          })
        )}
      </div>

    </div>
  );
}
