export type Role = 'admin' | 'teacher' | 'student';

export interface User {
  id: string;
  role: Role;
  email: string;
}

export interface Student {
  id?: string;
  userId: string;
  name: string;
  class: string;
  course: string;
  enrollmentDate: string;
  phone: string;
  email: string;
  address?: string;
  schoolName?: string;
  batchId?: string;
}

export interface Teacher {
  id?: string;
  name: string;
  subject: string;
  phone: string;
  email: string;
}

export interface Attendance {
  id?: string;
  studentId: string;
  date: string;
  status: 'present' | 'absent' | 'late';
}

export interface Mark {
  id?: string;
  studentId: string;
  examName: string;
  subject: string;
  marksObtained: number;
  totalMarks: number;
  date: string;
}

export interface Fee {
  id?: string;
  studentId: string;
  amount: number;
  status: 'paid' | 'pending';
  dueDate: string;
  paymentDate: string;
}

export interface Assignment {
  id?: string;
  title: string;
  description: string;
  class: string;
  course: string;
  dueDate: string;
}

export interface CourseFee {
  id?: string;
  class: string;
  course: string;
  amount: number;
}

export interface Enrollment {
  id?: string;
  userId: string;
  name: string;
  class: string;
  course: string;
  phone: string;
  email: string;
  address: string;
  schoolName: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
}

export interface Announcement {
  id?: string;
  title: string;
  content: string;
  authorId: string;
  authorName: string;
  createdAt: string;
}

export interface Lecture {
  id?: string;
  title: string;
  description: string;
  class: string;
  course: string;
  videoUrl: string;
  scheduledFor: string;
  authorName: string;
  createdAt: string;
  batchId?: string; // Optional batch filtering
  isLocked?: boolean;
  isPinned?: boolean;
}

export interface Batch {
  id?: string;
  name: string;
  class: string;
  teacherId: string;
  teacherName: string;
  image?: string;
  startDate: string;
  endDate: string;
  timing: string;
  classDays: string[]; // e.g. ["Mon", "Wed", "Fri"]
  createdAt: string;
}

export interface Course {
  id?: string;
  name: string;
  class: string;
  subjects: string[]; // e.g. ["Physics", "Chemistry", "Maths"]
  chapters: { [subject: string]: string[] }; // Subject -> Chapters mapping
  createdAt: string;
}

export interface StudyMaterial {
  id?: string;
  title: string;
  type: 'pdf' | 'image' | 'ppt' | 'mindmap' | 'doc' | 'zip';
  fileUrl: string;
  batchId: string;
  subject: string;
  chapter: string;
  createdAt: string;
  downloadsCount: number;
}

export interface Homework {
  id?: string;
  title: string;
  description: string;
  batchId: string;
  subject: string;
  chapter: string;
  dueDate: string;
  fileUrl?: string; // Task PDF/Image
  createdAt: string;
}

export interface HomeworkSubmission {
  id?: string;
  homeworkId: string;
  studentId: string;
  studentName: string;
  answerUrl: string; // Answer sheet
  submittedAt: string;
  status: 'pending' | 'graded';
  marks?: number;
  remarks?: string;
}

export interface MCQQuestion {
  question: string;
  options: string[];
  correctAnswer: number; // Index (0 to 3)
}

export interface Test {
  id?: string;
  title: string;
  batchId: string;
  subject: string;
  durationMinutes: number;
  questions: MCQQuestion[];
  isPublished: boolean;
  createdAt: string;
}

export interface TestSubmission {
  id?: string;
  testId: string;
  studentId: string;
  studentName: string;
  answers: number[]; // User selected options indices
  score: number;
  totalQuestions: number;
  submittedAt: string;
}

export interface Notification {
  id?: string;
  title: string;
  content: string;
  type: 'notice' | 'homework' | 'exam' | 'holiday' | 'fee' | 'live' | 'video';
  batchId: string; // "All" or a specific batch ID
  createdAt: string;
}

export interface Timetable {
  id?: string;
  batchId: string;
  day: string; // "Monday", etc.
  subject: string;
  time: string; // e.g. "4:00 PM - 5:30 PM"
  teacherName: string;
}
